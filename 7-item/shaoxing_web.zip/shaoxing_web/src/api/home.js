import request from '../utils/requests'
import { api } from '../utils/index'

const getHotSearch = () => {
    return request.get(`${api}/api/qyhbxx/getHotSearch`)
};
// 企业名称热搜
const getSystemInfo = (data) => {
    return request.post(`${api}/api/qyhbxx/getSystemInfo`, data)
};
// 获取科室信息系统
const companyBasicInfoList = (data) => {
    return request.post(`${api}/api/qyhbxx/companyBasicInfoList`, data)
};
// 门户企业信息搜索
const companyBasicInfoDetail = (data) => {
    return request.post(`${api}/api/qyhbxx/companyBasicInfoDetail`, data)
};
// 企业基本信息明细
const checkNet = () => {
    return request.get(`${api}/api/qyhbxx/checkNet`)
};
// 检测网咯是否为内网
const checkVerify = (data) => {
    return request.post(`${api}/api/qyhbxx/checkVerify`,data)
};
// 校验图片验证码
const getOdorEvaluationByName = (data) => {
    return request.post(`${api}/api/qyhbxx/getOdorEvaluationByName`,data)
};
// 异味评价信息
const downloadPDFile = (data) => {
    return request.get(`${api}/api/qyhbxx/downloadPDFile?code=${data}`)
};
// 下载PDF文件
const getPullutionInfoByName = (data) => {
    return request.post(`${api}/api/qyhbxx/getPullutionInfoByName`,data)
};
// 企业排污信息
const getVerify = () => {
    return request.get(`${api}/api/qyhbxx/getVerify`)
};
// 生成图片验证码
const login = (data) => {
    return request.post(`${api}/api/qyhbxx/login`,data)
};
// 外网用户登陆
const permitInfo = (data) => {
    return request.post(`${api}/api/qyhbxx/permitInfo`,data)
};
// 排污行政许可信息查询
const petitionRecord = (data) => {
    return request.post(`${api}/api/qyhbxx/petitionRecord`,data)
};
// 企业信访信息查询
const syhbzfCaseInfo = (data) => {
    return request.post(`${api}/api/qyhbxx/syhbzfCaseInfo`,data)
};
// 环境执法案例信息查询
const getFiveSource = (data) => {
    return request.post(`${api}/api/qyhbxx/getFiveSource`,data)
//   五大源
};
export default {
    getHotSearch,
    getSystemInfo,
    companyBasicInfoList,
    companyBasicInfoDetail,
    checkNet,
    checkVerify,
    getOdorEvaluationByName,
    downloadPDFile,
    getPullutionInfoByName,
    getVerify,
    login,
    permitInfo,
    petitionRecord,
    syhbzfCaseInfo,
    getFiveSource
}