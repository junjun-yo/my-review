<template>
  <div class="map-box">
    <el-amap
      ref="map"
      
      :amap-manager="amapManager"
      :center="mapObj.center"
      :zoom="zoom"
      :dragEnable="dragEnable"
      class="amap-demo"
    >
      <el-amap-marker
        vid="component-marker"
        :position="mapObj.center"
        :label="label"
      ></el-amap-marker>
      <!-- <el-amap-info-window :position="center" :content="content"></el-amap-info-window> -->
    </el-amap>
  </div>
</template>
<script>
import Apis from "../api/home";
import VueAMap from "vue-amap";

VueAMap.initAMapApiLoader({
  key: "df6fde4ed98bc5fd0f088303137fa0e0",
  // plugin: ['AMap.Autocomplete', 'AMap.PlaceSearch', 'AMap.Scale', 'AMap.OverView', 'AMap.ToolBar', 'AMap.MapType', 'AMap.PolyEditor', 'AMap.CircleEditor','AMap.Geolocation','AMap.DistrictSearch'],
  // 默认高德 sdk 版本为 1.4.4
  v: "1.4.4",
  uiVersion: "1.0.11" // 版本号
});
let amapManager = new VueAMap.AMapManager();
let that = this;
//   Vue.use(VueAMap);
export default {
  name: "Map",
  data() {
    return {
      amapManager,
      dragEnable: true,
      zoom: 12,
      label: {
        content: "",
        offset: [0, -22]
      },
      //   contentRender: (h, instance) => {
      //         // if use jsx you can write in this
      //         // return <div style={{background: '#80cbc4', whiteSpace: 'nowrap', border: 'solid #ddd 1px', color: '#f00'}} onClick={() => ...}>marker inner text</div>
      //         return h(
      //         'div',
      //         {
      //             style: {background: '#80cbc4', whiteSpace: 'nowrap', border: 'solid #ddd 1px', color: '#f00'},
      //             on: {
      //             click: () => {
      //                 const position = this.renderMarker.position;
      //                 this.renderMarker.position = [position[0] + 0.002, position[1] - 0.002];
      //             }
      //             }
      //         },
      //         ['marker inner text']
      //         )
      //     }
    };
  },
  created() {
    // this.getHotSearch();
    // console.log(this.mapObj)
  },
  props: {
    mapObj: Object
  },
  watch: {
      mapObj: {
        handler(newName, oldName) {
            console.log(newName)
            this.label = newName.label;
        },
        deep: true,
      }
  },
  methods: {
    // getHotSearch() {
    //   Apis.getHotSearch()
    //     .then(res => {
    //       if (res.code == 200) {
    //         this.hotText = res.data.list;
    //       } else {
    //         this.$message({
    //           type: "error",
    //           message: res.message
    //         });
    //       }
    //     })
    //     .catch(erro => {
    //       console.log(erro);
    //     });
    // },
    // searchGo() {
    //   this.$router.push({ path: "/screen" });
    // },
    // setValue(v) {
    //   this.searchValue = v;
    // }
  }
};
</script>
<style lang="less" scoped>
.map-box {
  width: 100%;
  height: 100%;
}
</style>
