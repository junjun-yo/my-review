<template>
  <div class="banner">
    <div class="content">
      <p>
        智慧环保中心
        <span class="address">(上虞)</span>综合信息查询系统
      </p>
      <div class="DivInline search-box m40">
        <div class="search-item">
          <el-input v-model.trim="searchValue" placeholder="请输入企业名称/关键字" clearable></el-input>
          <span class="search-btn" @click="searchGo">查询</span>
        </div>
      </div>
      <div class="hot-box">
        <div class="hotTitle">
          <span>热搜：</span>
        </div>
        <div class="hotTip">
          <ul>
            <li v-for="(item,index) in hotText" :key="index" @click="setValue(item.hotKeyword)">
              <a href="#">{{item.hotKeyword}}</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Apis from "../api/home";
export default {
  data() {
    return {
      searchValue: "",
      hotText: []
    };
  },
  created() {
   
        this.getHotSearch();
      
    
  },
  methods: {
    getHotSearch() {
      
      // if(this.searchValue.length<=0){
      //   alert('请输入您要查询的关键词')
      // }
      
      Apis.getHotSearch().then(res => {
        if (res.code == 200) {
          this.hotText = res.data.list;
        } 
        else {
          this.$message({
            type: "error",
            message: res.message
          });
        }
      }).catch(erro=>{
        console.log(erro)
      });
    },
    // 企业热搜功能
    searchGo() {
      if(this.searchValue.length>0)
      this.$router.push({
            path: '/screen',
            query: {
              seat: this.searchValue
            }
    	 });
      
    },
    setValue(v) {
      this.searchValue = v;
    }
  }
};
</script>
<style lang="less" scoped>
@import "../assets/css/search.css";
.banner {
  background-image: url("../assets/img/banner.png");
  width: 100%;
  height: 500px;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: 0 0;
  padding: 150px 0;
  box-sizing: border-box;
  .content {
    width: 1160px;
    height: 100%;
    margin: 0 auto;
    text-align: center;
    // background-color: #000;
    p {
      font-size: 35px;
      margin-bottom: 50px;
      color: #fff;
    }
    .search-item {
      position: relative;
      .search-btn {
        position: absolute;
        width: 100px;
        right: 0;
        top: 50%;
        margin-top: -14px;
        text-align: center;
        height: 28px;
        line-height: 28px;
        font-size: 20px;
        color: rgba(0, 109, 235, 1);
        border-left: 1px solid #0972eb;
        cursor: pointer;
      }
    }
  }
  .hot-box {
    height: 50px;
    line-height: 50px;
    width: 650px;
    margin: 0 auto;
    text-align: left;
    opacity: 0.9;
    color: rgba(255, 255, 255, 1);
    .hotTitle {
      width: 50px;
      float: left;
    }
    .hotTip {
      float: right;
      width: 600px;
      height: 50px;
      ul {
        li {
          float: left;
          padding: 0 10px;
          a {
            max-width: 80px;
            display: inline-block;
            color: rgba(255, 255, 255, 1);
            opacity: 0.8;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          a:hover {
            opacity: 1;
            text-decoration: underline;
          }
        }
      }
    }
  }
}
.address {
  display: inline-block;
  margin: 0 16px;
}
</style>
<style>
.banner .el-input__inner {
  border: 0;
  height: 50px;
  line-height: 50px;
}
.banner .el-input-group__append {
  background-color: #fff;
  border: 0;
}
.banner .el-input__suffix .el-input__icon {
  line-height: 50px;
}
.banner .el-input-group__append span {
  font-size: 16px;
  font-weight: 400;
  color: rgba(0, 109, 235, 1);
}
.banner .el-input-group__append {
  border-left: 1px solid rgba(9, 114, 235, 1);
  height: 40px;
}
.banner .el-input__inner {
  font-size: 20px;
  padding-right: 150px;
}
.banner .el-input__suffix {
  right: 120px;
}
.banner .search-box .el-button--primary:focus,
.banner .search-box .el-button--primary:hover {
  background: rgba(0, 109, 235, 1);
  border-color: rgba(0, 109, 235, 1);
  color: #fff;
}
</style>