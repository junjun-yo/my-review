<template>
  <el-header>
    <div class="header-main">
      <div class="h-title DivInline" @click="goback">
        <span>
          智能环保中心
          <span class="address">(上虞)</span>综合信息查询系统
        </span>
      </div>
      <!-- ---------------------已登录---------------------- -->
      <div class="Landed" v-if="$route.path === '/home'? false: true">
        <div class="DivInline search-box mr100">
          <div class="search-item">
            <el-input placeholder="请输入内容" v-model="comValue" clearable class="searchInput">
              <template slot="append">
                <span class="searchBtn" @click="getuserlist">查询</span>
              </template>
            </el-input>
          </div>
        </div>
      </div>
      <!-- ---------------------已登录结束------------------------- -->
      <!-- ------------------未登陆-------------------------- -->
      <div v-if="netFlag != 'outside'">
        <div class="NotLanded" v-if="this.userInfo.userName">
          <span>{{userInfo.userName}}</span>
          <el-button type="primary" round size="small" class="unloginBtn" @click="LoginOut">退出</el-button>
        </div>
        <div class="NotLanded" v-else>
          <div class="login DivInline">
            <el-button type="primary" round size="small" class="loginBtn" @click="goLogin">登录</el-button>
          </div>
        </div>
      </div>
      <!-- -------------------未登陆结束----------------- -->
    </div>
    <el-dialog title :visible.sync="dialogVisible" width="900px" :before-close="handleClose">
      <div class="loginDialog">
        <div class="login-img">
          <img src="../assets/img/Rectangle.png" alt />
        </div>
        <div class="login-content">
          <p>
            用户登录
            <span>USER LOGIN</span>
          </p>
          <el-form :model="LoginForm" class="LoginForm" :rules="rlues" ref="LoginForm">
            <el-form-item label prop="name">
              <el-input class="loginFormInput" v-model.trim="LoginForm.name" placeholder="请输入账号" ></el-input>
            </el-form-item>
            <el-form-item label prop="psw">
              <el-input
                class="loginFormInput"
                v-model.trim="LoginForm.psw"
                placeholder="请输入密码"
                type="password"
              ></el-input>
            </el-form-item>
            <el-form-item label prop="yzm">
              <div>
                <el-input class="loginFormyzm" v-model.trim="LoginForm.yzm" placeholder="验证码"></el-input>
                <img :src="codeInfo.data" @click="getCode" alt />
              </div>
            </el-form-item>
          </el-form>
          <el-button type="primary" class="dialogBtn" @click="Login('LoginForm')">登录</el-button>
        </div>
      </div>
    </el-dialog>
  </el-header>
</template>
<script>
import Apis from "../api/home";
import {bus} from "../utils/bus";

export default {
  data() {
    return {
      comValue: "",
  // 搜索框里面的值
  message:'',
      flag: false,
      dialogVisible: false,
      LoginForm: {
        username: 'admin',
        password: '123456'
      },
      LandedIsShow: true,
      rlues: {
        name: [
          { required: true, message: "请输入账号", trigger: "blur" },
          { min: 0, max: 20, message: "长度在 0 到 20 个字符", trigger: "blur" }
        ],
        psw: [{ required: true, message: "请输入密码", trigger: "blur" }],
        yzm: [{ required: true, message: "请输入验证码", trigger: "blur" }]
      },
      netFlag: null,    //内外网判断
      codeInfo: {    //验证码信息
        data: '',
      },
      userInfo: {   //用户信息
        name: '',       //真实姓名
        userName: '',   //用户名
        login_times: '',  //登陆次数
        departmentName: '',   //所属部门科室
      },
    };
  },
  computed: {
    showUser() {

    }
  },
  methods: {
    getLoginTrue(){


    },
    goLogin() {
      this.dialogVisible = true;
      this.getCode();   //获取验证码
    },
    Login(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
         
          this.getUserInfo();   //用户登录
      
          
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 登录模块的校验
    goback(){
      this.$router.push('/home');
    },
    LoginOut() {
      this.userInfo = {   //用户信息
        name: '',       //真实姓名
        userName: '',   //用户名
        login_times: '',  //登陆次数
        departmentName: '',   //所属部门科室
      }
    },
    handleClose(done) {
      // this.$confirm("确认关闭？")
      //   .then(_ => {
      done();
      // })
      // .catch(_ => {});
    },
    getuserlist(){
      
      // this.bus.$on('query',(msg)=>{
      //   // console.log(this.comValue)
      //   let obj=JSON.parse(msg);
      //   let query={}
      //   query['seat']=this.comValue
      //   for(var key in obj){
      //     query[key]=obj[key]
      //   }

      // this.$router.push({
      //       path: '/screen',
      //       query:query
      // });
    	//  })
      // // 查询的时候，都重定向到screen页面

      this.$router.push({
            path: '/screen',
            query:{
              seat:  this.comValue
            }
      });
      // console.log(this.$route.path)
      if(this.$route.path == '/screen'){
        bus.$emit('search')
      }

    },
    // 搜索框查询按钮跳转
    getNet() {    //查询内外网
      Apis.checkNet()
        .then(res => {    
          // console.log(res)
          if(res){      //true内网  false外网
            this.netFlag = 'inside';
          }else{
            this.netFlag = 'outside';
          }
        })
        .catch(erro => {
          console.log(erro);
        });
    },
    getCode() {    //获取验证码
      Apis.getVerify()
        .then(res => {    
          console.log(res)
          if (res.code == 200) {
            this.codeInfo = res.data.getVerify;
          } else {
            this.$message({
              type: "error",
              message: res.message
            });
          }
        })
        .catch(erro => {
          console.log(erro);
        });
    },
    checkVerify() {     //校验验证码
      let data = {
        code: this.LoginForm.yzm,
        imageKey: this.codeInfo.imageKey
      };
      Apis.checkVerify(data)
        .then(res => {    
          console.log(res)
          if (res) {
            this.codeInfo = res.data.getVerify;
          } else {
            this.$message({
              type: "error",
              message: '验证码有误！'
            });
          }
        })
        .catch(erro => {
          console.log(erro);
        });
    },
    getUserInfo() {   //用户登录
      let data = {
        userName: this.LoginForm.name,
        password: this.LoginForm.psw,
        verifyCode: this.LoginForm.yzm,
        imageKey: this.codeInfo.imageKey
      };
      Apis.login(data)
        .then(res => {    
          console.log(res)
          if (res.success) {
            // this.codeInfo = res.data.getVerify;
            this.userInfo = res.data.login;
            sessionStorage.setItem('token', res.data.token);
            this.$refs['LoginForm'].resetFields();
            this.dialogVisible = false;
          } else {
            this.$message({
              type: "error",
              message: res.message
            });
            this.getCode();   //获取验证码
          }
        })
        .catch(erro => {
          console.log(erro);
        });
    }
  },
  created() {
    if (this.$route.path === "/home") {
      this.LandedIsShow = false;
    } else {
      this.LandedIsShow = true;
    }
    this.getNet();    //查询是否为内网
    
  },
  updated() {
    if(this.$route.query.seat){
      this.comValue = this.$route.query.seat;
    }
  }
};
</script>
<style  lang="less" scoped>
.el-header {
  width: 100%;
  height: 60px;
  background-color: #fff;
  box-shadow: 0px 2px 4px 0px rgba(169, 169, 169, 0.5);
  .header-main {
    width: 1160px;
    cursor: pointer;
    margin: 0 auto;
    .h-title {
      float: left;
      color: rgba(0, 109, 235, 1);
      line-height: 60px;
      font-weight: 600;
      padding-right: 55px;
    }
    .NotLanded {
      float: right;
      line-height: 60px;
      span {
        color: #006deb;
        display: inline-block;
        margin: 0 20px;
        font-size: 16px;
      }
    }
    .Landed {
      float: left;
      .search-box {
        display: inline-block;
        width: 500px;
        height: 35px;
        padding: 12.5px 20px;
        .search-item {
          background: rgba(255, 255, 255, 1);
          border-radius: 4px;
          border: 1px solid rgba(0, 109, 235, 1);
          width: 500px;
          height: 35px;
          .searchInput {
            width: 500px;
          }
        }
      }
      span {
        color: rgba(0, 109, 235, 1);
        display: inline-block;
        margin: 0 20px;
      }
    }
    .login {
      float: right;
      line-height: 60px;
    }
  }
}
.address {
  display: inline-block;
  margin: 0 8px;
}
.loginDialog {
  width: 900px;
  height: 500px;
  padding: 55px 15px;
  box-sizing: border-box;
  .login-img {
    width: 411px;
    height: 412px;
    float: left;
    img {
      width: 100%;
    }
  }
  .login-content {
    float: right;
    width: 450px;
    // background-color: blue;
    p {
      color: rgba(51, 51, 51, 1);
      font-size: 24px;
      // background: pink;
      margin-bottom: 30px;
      span {
        color: rgba(204, 204, 204, 1);
        font-size: 24px;
        margin-left: 20px;
      }
    }
    .LoginForm {
      div {
        img {
          width: 160px;
          height: 49px;
        }
      }
    }
    .dialogBtn {
      width: 354px;
      height: 50px;
      font-size: 24px;
      background-color: rgba(0, 109, 235, 1);
      margin-top: 45px;
      border-radius: 12px;
    }

    .loginFormInput {
      margin-bottom: 25px;
    }

    .loginFormyzm {
      width: 189px;
      height: 50px;
    }
  }
}
</style>
<style>
.el-header .Landed .search-box .el-input__inner {
  border: 0;
  height: 35px;
  line-height: 35px;
}
.el-header .Landed .search-box .el-input-group__append {
  background-color: #fff;
  border: 0;
}
.el-header .Landed .search-box .el-input__suffix .el-input__icon {
  line-height: 35px;
}
.el-header .Landed .search-box .el-input-group__append span {
  font-size: 16px;
  font-weight: 400;
  color: rgba(0, 109, 235, 1);
}
.el-header .el-dialog__body {
  padding: 0;
}
.el-header .el-dialog__header {
  padding: 0;
}
.el-header .el-input__suffix {
  right: 0;
}
.loginFormInput .el-input__inner {
  border-radius: 8px;
  width: 350px;
  height: 50px;
}
.el-header .el-input-group__append,
.el-input-group__prepend {
  padding: 0;
}
.loginFormyzm .el-input__inner {
  border-radius: 8px;
  width: 189px;
  height: 50px;
}
.main .loginDialog .login-content .loginFormInput {
  margin-bottom: 0px;
}
.el-icon-circle-close:before {
    content: "\E79D";
}
</style>