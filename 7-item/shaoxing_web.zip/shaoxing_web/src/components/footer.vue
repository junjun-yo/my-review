<template>
  <el-footer>
    <p>技术支持联系方式：453636@163.com 0575-87342921429</p>
    <p>©2019绍兴市生态环境局上虞分局 版权所有</p>
  </el-footer>
</template>
<script>
export default {
  data() {
    return {};
  }
};
</script>
<style lang="less" scoped>
.el-footer {
  width: 100%;
  height: 96px !important;
  color: rgba(209, 209, 209, 1);
  position:absolute;
  bottom:0px;
  text-align: center;
  padding: 30px 0;
  box-sizing: border-box;
  background-color: rgba(43, 52, 61, 1);
  p {
    font-size: 16px;
  }
}
</style>
