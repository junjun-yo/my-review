import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
    routes: [{
        path: '/',
        name: 'basicLayout',
        component: resolve => require(['@/views/basicLayout/index'], resolve),
        redirect: '/home',
        children: [{
                path: '/home',
                name: 'home',
                component: resolve => require(['@/views/home/index'], resolve)
            }, {
                path: '/screen',
                name: 'screen',
                component: resolve => require(['@/views/companySearch/screen'], resolve)
            },
            {
                path: '/basicInformation/:id',
                name: 'basicInformation',
                component: resolve => require(['@/views/companyMsg/basicInformation'], resolve)
            },

        ]
    }]
})