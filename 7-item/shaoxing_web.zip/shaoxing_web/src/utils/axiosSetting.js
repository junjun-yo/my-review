import axios from 'axios'
axios.defaults.timeout = 120000;
axios.defaults.headers = {
        'Content-Type': 'application/json'
    }
    // respone拦截器
axios.interceptors.response.use(
    response => {
        return response.data;
    }
);