import axios from 'axios'
import './axiosSetting'

/**
 * 封装get请求
 * @param { String } url 请求路径
 * @param { Object } 请求参数
 *  params GET请求参数
 */
const get = (url, config) => {
        return axios.get(url, config)
    }
    /**
     * 封装post请求
     * @param { Object } 请求参数
     *  data POST请求请求参数，对象形式
     */
const post = (url, data, config) => {
    return axios.post(url, data, config)
}


const _delete = (url, config) => {
    return axios.delete(url, config)
};
export default {get, post, _delete }