// export const api = 'http://192.168.3.6:8091'
export const api = 'http://39.100.53.146:9002' /*测试*/
// export const api = 'http://192.168.3.53:8091' 