<template>
  <div class="container">
    <div class="content-Header">
      <div class="ResultMsg">
        <div class="ResultMsg-Img">
          <img src="@/assets/img/company.png" alt />
        </div>
        <div class="ResultMsg-Text"  >
          <div class="ResultMsg-top">
            <p>{{list.companyName}}</p>
            <button v-if="list.operateStatus=='存续'" class="small-button greenBorder basicStateBtn">存续</button>
            <button v-else-if="list.operateStatus='注销'" class="small-button basicStateBtn redBorder">注销</button>
            <button v-else-if="list.operateStatus=='迁出'" class="small-button basicStateBtn greyBorder">迁出</button>
            <button v-else-if="list.operateStatus='吊销-已注销'" class="small-button basicStateBtn greyBorder">吊销-已注销</button>
            <button v-else-if="list.operateStatus=='吊销-未注销'" class="small-button basicStateBtn greyBorder">吊销-未注销</button>
          </div>
          <div class="Text-details">
            <span>法定代表人：{{list.legalPerson}}</span>
            <span>成立时间：{{list.setUpTime}}</span>
          </div>
          <div class="Text-details">
            <span>联系人：{{list.contactor}}</span>
            <span>电话：{{list.tel}}</span>
          </div>
          <div class="Text-details">
            <span>地址：{{list.address}}</span>
          </div>
        </div>
      </div>
      <div class="MapMsg" >
        <!-- <img src="../../assets/img/map.png" alt /> -->
        <Map :mapObj="mapInfo"></Map>
        <div class="map-btn" @click="showMap"></div>
      </div>

      <el-dialog
        :visible.sync="mapFlag"
        width="80%"
        >
        <div class="map-big">
          <Map :mapObj="mapInfo"></Map>
        </div>
      </el-dialog>

      <div class="PdfMsg">
        <!-- 利用a链接，实现下载功能 -->
         <a href="#" class="textBorderBtn" @click="download">下载PDF报告</a>
      </div>
    </div>
    <div class="content-Box">
      <!-- 按钮 -->
      <div class="btn-List">
        <button
          :class="item.active ? 'basicBtnActive':null "
          class="basicBtn"
          v-for="(item,index) in btnList"
          :key="index"
          @click="changeTab(item,index)"
        >{{item.title}}</button>
        <!-- 点击不同按钮，显示不同的内容 -->
      </div>
      <!-- 基础信息 -->
      <div v-show="tabListIsShow[0].show" >
        <div class="Tab-list">
          <div class="tabTitle">
            <p>工商信息</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">统一社会信用代码</td>
                <td style="width:25%;" class="color84">{{list.creditCode || '-'}}</td>
                <td style="width:25%;">组织机构代码</td>
                <td style="width:25%;" class="color84">{{list.organizationCode || '-'}}</td>
              </tr>
              <tr>
                <td>注册号</td>
                <td class="color84">{{list.registNumber || '-'}}</td>
                <td>经营状态</td>
                <td class="color84">{{list.operateStatus || '-'}}</td>
              </tr>
              <tr>
                <td>所属行业</td>
                <td class="color84">{{list.industry || '-'}}</td>
                <td>成立日期</td>
                <td class="color84">{{list.setUpTime || '-'}}</td>
              </tr>
              <tr>
                <td>公司类型</td>
                <td class="color84">有限责任公司</td>
                <td>营业期限</td>
                <td class="color84">_</td>
              </tr>
              <tr>
                <td>法定代表人</td>
                <td class="color84">{{list.legalPerson || '-'}}</td>
                <td>发照日期</td>
                <td class="color84">_</td>
              </tr>
              <tr>
                <td>注册资本</td>
                <td class="color84">{{list.registCapital || '-'}}</td>
                <td>登记机关</td>
                <td class="color84">_</td>
              </tr>
              <tr>
                <td>企业地址</td>
                <td colspan="3" class="color84">{{list.address || '-'}}</td>
              </tr>
              <tr>
                <td>经营范围</td>
                <td colspan="3" class="color84">_</td>
              </tr>
            </table>
          </div>
        </div>
        <div class="Tab-list">
          <div class="tabTitle">
            <p>变更信息</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">变更日期</td>
                <td style="width:25%;">变更项目</td>
                <td style="width:25%;">变更前</td>
                <td style="width:25%;">变更后</td>
              </tr>
              <tr>
                <td class="color84">_</td>
                <td class="color84">_</td>
                <td class="color84">_</td>
                <td class="color84">_</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <!-- 行政许可 -->
      <div v-show="tabListIsShow[1].show" :data="accept">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>排污许可证</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
            <tr>
                  <td style="width:25%;">许可证编号</td>
                  <td style="width:75%;" class="color84">{{accept.licenceCode || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">排污单位名称</td>
                  <td style="width:75%;" class="color84">{{accept.sewageDisposalCompany || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">所在省/直辖市</td>
                  <td style="width:75%;" class="color84">{{accept.province || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">所在市</td>
                  <td style="width:75%;" class="color84">{{accept.city || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">所在区县</td>
                  <td style="width:75%;" class="color84">{{accept.area || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">行业类别</td>
                  <td style="width:75%;" class="color84">{{accept.industryCategory || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">许可证管理类别</td>
                  <td style="width:75%;" class="color84">{{accept.licenceCategory || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">是否需整改</td>
                  <td style="width:75%;" class="color84">{{accept.isRectification || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">发证时间</td>
                  <td style="width:75%;" class="color84">{{accept.issuanceTime || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">核发机关</td>
                  <td style="width:75%;" class="color84">{{accept.office || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">有效期限</td>
                  <td style="width:75%;" class="color84">{{accept.effectiveTime || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">办结时间</td>
                  <td style="width:75%;" class="color84">{{accept.settlementTime || '-'}}</td>
                </tr>
                <tr>
                  <td style="width:25%;">办理类型</td>
                  <td style="width:75%;" class="color84">{{accept.processCategory || '-'}}</td>
                </tr>
            </table>
          </div>
        </div>
        <div class="Tab-list">
          <div class="tabTitle">
            <p>登记备案</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">备案号</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">备案日期</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">项目名称</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">建设地点</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">建设单位</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">建设性质</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联系人</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联系电话</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">项目投资(万元)</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">环保投资(万元)</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">备注</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      
      <!-- 环境执法 -->
      <div v-show="tabListIsShow[2].show" :data="environment">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>环境执法案件信息</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">案件状态</td>
                <td style="width:75%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">当事人名称</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">案件来源</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">统一社会信用代码</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">地址</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">法定代表人</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">法定代表人身份证号码</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">联系电话</td>
                <td style="width:75%;" class="color84">——</td>
              </tr>
              <tr>
                <td style="width:25%;">地域</td>
                <td style="width:75%;" class="color84">{{environment.region || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">案件承办人</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">立案时间</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">调查报告时间</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">案发时间</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">案由</td>
                <td style="width:75%;" class="color84">{{environment.caseName || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">处罚金额(元)</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">告知书编号</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">告知书下发时间</td>
                <td style="width:75%;" class="color84">—</td>
              </tr>
              <tr>
                <td style="width:25%;">处罚决定书文号</td>
                <td style="width:75%;" class="color84">{{environment.decisionRefno || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">处罚决定书下发时间</td>
                <td style="width:75%;" class="color84">{{environment.decisionDate || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">责令改正形式</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">处理依据</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">处罚种类</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">处罚建议</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">立案编号</td>
                <td style="width:75%;" class="color84">{{environment.filingCode || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">当事人类型</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">案件类型</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">告知书类型</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">告知书草拟时间</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">内审表编号</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
              <tr>
                <td style="width:25%;">内审日期</td>
                <td style="width:75%;" class="color84">_</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <!-- 信访信息 -->
      <div v-show="tabListIsShow[3].show" :data="messageVist">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>环境信访档案</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">信访编号</td>
                <td style="width:25%;" class="color84">{{messageVist.petitionRefno || '-'}}</td>
                <td style="width:25%;">受理人</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉人姓名</td>
                <td style="width:25%;" class="color84">{{messageVist.complainant || '-'}}</td>
                <td style="width:25%;">投诉时间</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintTime || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉重复次数</td>
                <td style="width:25%;" class="color84">{{messageVist.repeatComplaintNum || '-'}}</td>
                <td style="width:25%;">投诉渠道</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintChannel || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">联系电话</td>
                <td style="width:25%;" class="color84">{{messageVist.contactNo || '-'}}</td>
                <td style="width:25%;">E-mail</td>
                <td style="width:25%;" class="color84">{{messageVist.complainantEmail || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">证件类型</td>
                <td style="width:25%;" class="color84">{{messageVist.certificateType || '-'}}</td>
                <td style="width:25%;">证件号码</td>
                <td style="width:25%;" class="color84">{{messageVist.certificateNum || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">是否越级访</td>
                <td style="width:25%;" class="color84">{{messageVist.isBypass || '-'}}</td>
                <td style="width:25%;">是否有异常行为</td>
                <td style="width:25%;" class="color84">{{messageVist.ifAbnormalHehavior || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">转入件编码</td>
                <td style="width:25%;" class="color84">{{messageVist.insertNumber || '-'}}</td>
                <td style="width:25%;">是否保密</td>
                <td style="width:25%;" class="color84">{{messageVist.isSecret || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">污染类型</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">是否有非法环境违法行为</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">处理方案</td>
                <td style="width:25%;" class="color84">{{messageVist.emergency || '-'}}</td>
                <td style="width:25%;">重要程度</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintLevel || '-'}}</td>
              </tr>

              <tr>
                <td style="width:25%;">受理时间</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">发生地点</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉方式</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintWay || '-'}}</td>
                <td style="width:25%;">投诉出处</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintSource || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">交办编号</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">随访人</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉人地址</td>
                <td style="width:25%;" class="color84">{{messageVist.complainantAddress || '-'}}</td>
                <td style="width:25%;">投诉类别</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintType || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">信访人数</td>
                <td style="width:25%;" class="color84">{{messageVist.petitionPersonSum || '-'}}</td>
                <td style="width:25%;">是否集体访</td>
                <td style="width:25%;" class="color84">{{messageVist.isTeam || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">异常情况</td>
                <td style="width:25%;" class="color84">{{messageVist.abnormalHehavior || '-'}}</td>
                <td style="width:25%;">案件来源</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">被投诉单位</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">是否重点监控</td>
                <td style="width:25%;" class="color84">-</td>
              </tr>
              <tr>
                <td style="width:25%;">被投诉次数</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">信访类别</td>
                <td style="width:25%;" class="color84">{{messageVist.complaintType || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">是否需要会办</td>
                <td style="width:25%;" class="color84">{{messageVist.isCoworking || '-'}}</td>
                <td style="width:25%;">截止办理时间</td>
                <td style="width:25%;" class="color84">{{messageVist.deadline || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉主题</td>
                <td style="width:25%;" colspan="3" class="color84">{{messageVist.complaintGoal || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">投诉内容</td>
                <td style="width:25%;" colspan="3" class="color84">{{messageVist.complaintSubject || '-'}}</td>
              </tr>
              <tr>
                <td style="width:25%;">管辖区域</td>
                <td style="width:25%;" colspan="3" class="color84">{{messageVist.jurisdictionArea || '-'}}</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <!-- 排污信息 -->
      <div v-show="tabListIsShow[4].show" :data="emission">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>控制器信息</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">类型</td>
                <td style="width:25%;" class="color84" colspan="3">水</td>
              </tr>
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:25%;" class="color84">-</td>
                <td style="width:25%;">控制器ID</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">刷卡排污编号</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">区域</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">行业</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">控制级别</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联系人</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">联系电话</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
        </div>
        <div class="Tab-list">
          <div class="tabTitle">
            <p>排放数据</p>
          </div>
          <!-- 水报表start -->
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">类型</td>
                <td style="width:25%;" class="color84" colspan="3">水</td>
              </tr>
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">COD计划量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联网状态</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">COD充值量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">阀门状态</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">COD使用量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">季度</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">COD使用率</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">水量计划量( m<sup>3</sup> )</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">氨氮计划量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">水量充值量( m<sup>3</sup> )</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">氨氮充值量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">水量使用量( m<sup>3</sup> )</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">氨氮使用量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">水量使用率</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">氨氮使用率</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
          <!--水报表end -->
          <!-- 气报表start -->
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">类型</td>
                <td style="width:25%;" class="color84" colspan="3">气</td>
              </tr>
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">阀门状态(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联网状态</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">季度</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">SO2计划量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">NOx计划量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">SO2充值量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">NOx充值量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">SO2使用量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">NOx使用量(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">SO2使用率</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">NOx使用率</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
          <!--气报表end -->
        </div>
        <div class="Tab-list">
          <div class="tabTitle">
            <p>排量报表</p>
          </div>
          <!-- 水排量Start -->
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">类型</td>
                <td style="width:25%;" class="color84" colspan="3">水</td>
              </tr>
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">水量( m<sup>3</sup> )</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">数据时间</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">COD(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">备注</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">氨氮(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
          <!-- 水排量end -->
          <!-- 气排量Start -->
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">类型</td>
                <td style="width:25%;" class="color84" colspan="3">气</td>
              </tr>
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">SO2(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">数据时间</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">NOx(kg)</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
          <!-- 气排量end -->
        </div>
      </div>
      <!-- 异味评价 -->
      <div v-show="tabListIsShow[5].show">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>异味评价(站点)</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">企业名称</td>
                <td style="width:75%;" class="color84" colspan="3">水</td>
              </tr>
              <tr>
                <td style="width:25%;">位点名称</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">位点编码</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">位点类型</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">监测时间</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">臭氧浓度</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">首要污染物</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">评价等级</td>
                <td style="width:75%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <!-- 五大源 -->
      <div v-show="tabListIsShow[6].show">
        <div class="Tab-list">
          <div class="tabTitle">
            <p>移动源</p>
          </div>
          <div class="tab-table">
            <table align="center" cellspacing="1">
              <tr>
                <td style="width:25%;">年份</td>
                <td style="width:25%;" class="color84" colspan="3">2018-06-04</td>
              </tr>
              <tr>
                <td style="width:25%;">统一社会信用代码</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油年销售量（吨）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">组织机构代码</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">柴油年销售量（吨）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">单位详细名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">油气回收阶段汽油</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">单位负责人/个体工商户户主姓名</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油有无排放处理设备</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">所属加油站名称</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油在线监测系统</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">区划代码</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">油气回收装置改造完成时间改造完成时间年</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">省（自治区、直辖市）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">油气回收装置改造完成时间改造完成时间月</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">地区（市 、州 、盟）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">储罐类型汽油</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">县（区、市、旗）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">储罐类型柴油</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">乡（镇）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">储罐壳体类型汽油</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">街(村）、门牌号</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">储罐壳体类型柴油</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 经度_度</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油有无防渗池</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 经度_分</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">柴油有无防渗池</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 经度_秒</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油有无防渗漏监测设施</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 纬度_度</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">柴油有无防渗漏监测设施</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 纬度_分</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">汽油有无双层管道</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">企业地理坐标_ 纬度_秒</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">柴油有无双层管道</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">联系人</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">单位负责人</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">电话号码</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">统计负责人（审计人）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">汽油总罐容（立平米）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">填表人</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
              <tr>
                <td style="width:25%;">柴油总罐容（立平米）</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
                <td style="width:25%;">报出日期</td>
                <td style="width:25%;" class="color84">8384845495230545</td>
              </tr>
            </table>
          </div>
        </div>

      </div>
      <!-- 其他  保留按钮 -->
      <div v-show="tabListIsShow[7].show">
        <!-- 其他 内容暂定 -->
        <div class="nothing">
          <img src="../../assets/img/Group 8.png" alt />
          <span>暂无相关数据</span>
        </div>
      </div>
      <!-- 暂无相关数据 -->

    </div>
  </div>
</template>
<script>

//  下载PDF,引入相应的组件
import Apis from "../../api/home";
import Map from "../../components/map";
export default {
    name: "BasicInformation",
    data() {
    return {
     
      creditCode:this.$route.params.id,
      smell:[],
      // 异味评价
      source:{},
      // 五大源
    emission:[],
    // 排污
      list:{},
      environment:[],
      company:'',
      messageVist:{},
      // 信访信息
      creditCode:'',
      creditCode1:'91330604749839764K',
      companyName:'绍兴上虞一鑫针织印染有限公司',
      accept:[],
      mapFlag: false,   //地图弹窗
      mapInfo: {
        center: [0,0],
        label: {
          content: "",
          offset: [0, -22]
        }
      },
      btnList: [
        {
          title: "基础信息",
          type: 1,
          active: true
        },
        {
          title: "行政许可",
          type: 2,
          active: false
        },
        {
          title: "环境执法",
          type: 3,
          active: false
        },
        {
          title: "信访信息",
          type: 4,
          active: false
        },
        {
          title: "排污信息",
          type: 5,
          active: false
        },
        {
          title: "异味评价",
          type: 6,
          active: false
        },
        {
          title: "五大源",
          type: 7,
          active: false
        },
        {
          title: "其他",
          type: 8,
          active: false
        }
      ],
      // 默认的数据
      tabListIsShow: [
        {
          show: true
        },
        {
          show: false
        },
        {
          show: false
        },
        {
          show: false
        },
        {
          show: false
        },
        {
          show: false
        },
        {
          show: false
        },
        {
          show: false
        }
      ]
    };
  },
  created(){
    this.getNews()
  },
  mounted(){

  },
  components: {
    "Map": Map,
  },
  methods: {
    downloadWeekly(id,fileName){
        	//调用子组件的下载方法
            this.$refs.pdf.downloadPDF(Vue.prototype.ApiUrl+'/reports/download/'+id,fileName)
        },
        // 下载PDF
    //地图弹窗
    showMap() {
      this.mapFlag = true;
    },
      // 点击button 按扭
    changeTab(item, index) {
      // console.log(item, index);
      let btnFlag = this.tabListIsShow;
      this.btnList.forEach((ele, i) => {
        ele.active = false;
        this.tabListIsShow[i].show = false;
      });
      this.btnList[index].active = true;
      btnFlag[index].show = true;
      if(item.type===1){
           this.getNews();
      }
        if(item.type === 2){
          this.getPermitInfoList();
        }else if(item.type === 3){
          this.getSyhbzfCaseInfoList();
        }else if(item.type === 4){
          this.getPetitionRecordList();
        }else if(item.type === 5){
          this.getPullutionInfoByNameList();
        }else if(item.type === 6){
          this.getOdorEvaluationByNameList();
        }else if(item.type === 7){
          this.getFiveSourceList();
        }  
    },
    // 下载区域
     getNews(){
      this.creditCode=this.$route.params.id;
   let  message={
        creditCode:this.creditCode
      }
      Apis.companyBasicInfoDetail(message).then(res => {
        if (res.code == 200) {
          this.list = res.data.queryPermitEmissionOuput;
          // console.log(res);  
          this.company=res.data.queryPermitEmissionOuput.companyName
          // 获取企业的名称信息

          //获取地图参数
          this.mapInfo.center = [res.data.queryPermitEmissionOuput.longitude,res.data.queryPermitEmissionOuput.latitude];
          // this.mapInfo.label.content = res.data.queryPermitEmissionOuput.companyName;
          this.$set(this.mapInfo.label,'content',res.data.queryPermitEmissionOuput.companyName)
        } else {
          this.$message({
            type: "error",
            message: res.message
          });
        }
      }).catch(error=>{
        console.log(error)
      })
    },
    // 基础信息
     getPermitInfoList(){
      
       let  message={
        creditCode:this.creditCode1
      }
        Apis.permitInfo(message).then(res =>{
          if(res.code === 200){
            this.accept = res.data.queryPermitEmissionOuput[0]
            console.log(this.accept)
                console.log(res)
          }else {
              this.$message({
                type: "error",
                message: res.message
              })
          }
        }) .catch(erro => {
            console.log(erro);
          });
      },
      // 行政许可 (参数是)
    getSyhbzfCaseInfoList(){
         this.creditCode=this.$route.params.id;
   let  message={
        creditCode:this.creditCode1
      }
      Apis.syhbzfCaseInfo(message).then(res =>{
        if(res.code == 200){
          console.log(res)
          this.environment = res.data.querySyhbzfCaseOuput[0]
        }else {
            this.$message({
              type: "error",
              message: res.message
            })
        }
      }) .catch(erro => {
          console.log(erro);
        });
    },
     // 环境执法
   
    getPetitionRecordList(){
       let  input={
        companyName:this.companyName
        // companyName:this.company
      }
      Apis.petitionRecord(input).then(res =>{
        if(res.code == 200){
          console.log(res)
         this.messageVist=res.data.queryPetitionRecordDetailOuput[0]
        }else {
            this.$message({
              type: "error",
              message: res.message
            })
        }
      }) .catch(erro => {
          console.log(erro);
        });
    },
     // 信访信息(传入的参数是企业名称)
    
    getPullutionInfoByNameList(){
            // this.creditCode=this.$route.params.id;
   let  message={
        companyName:this.companyName
        // companyName:this.company
      }
      Apis.getPullutionInfoByName(message).then(res =>{
        if(res.code == 200){
          console.log(res)
           this.emission = res.data.queryPermitEmissionOuput
        }else {
            this.$message({
              type: "error",
              message: res.message
            })
        }
      }) .catch(erro => {
          console.log(erro);
        });
    },
    // 排污信息
    getOdorEvaluationByNameList(){
       let  message={
        // companyName:this.company
        companyName:this.companyName
      }

      Apis.getOdorEvaluationByName(message).then(res =>{
        if(res.code == 200){
          console.log(res)
          this.smell = res.data.list
        }else {
            this.$message({
              type: "error",
              message: res.message
            })
        }
      }) .catch(erro => {
          console.log(erro);
        });
    },
     // 异味评价
   
    getFiveSourceList(){
       let  message={
        companyName:this.companyName
        // companyName:this.company
      }
      Apis.getFiveSource(this.message).then(res =>{
        if(res.code == 200){
          console.log(res)
          this.source = res.data.map
        }else {
            this.$message({
              type: "error",
              message: res.message
            })
        }
      }) .catch(erro => {
          console.log(erro);
        });
    },
     // 五大源  
      download() {
        window.open('http://39.100.53.146:9002/api/qyhbxx/downloadPDFile?code='+this.creditCode);
      
    }
  }
}

</script>
<style lang="less" scoped>
.container {
  .content-Header {
    height: 220px;
    width: 100%;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 2px 4px 0px rgba(199, 199, 199, 0.5);
    border: 1px solid rgba(239, 239, 239, 1);
    margin-top: 15px;
    padding: 28px;
    box-sizing: border-box;
    .ResultMsg {
      float: left;
      padding: 17px 0;
      .ResultMsg-Img {
        float: left;
        width: 130px;
        height: 130px;
        border-radius: 8px;
        overflow: hidden;
        img {
          width: 100%;
        }
      }
      .ResultMsg-Text {
        float: left;
        margin-left: 20px;
        height: 130px;
        width: 535px;
        .ResultMsg-top {
          height: 25px;
          width: 425px;
          margin-bottom: 28px;
          p {
            float: left;
            font-size: 18px;
            font-weight: 700;
            color: rgba(31, 126, 237, 1);
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            // vertical-align: top;
          }
          .basicStateBtn {
            float: left;
            margin-left: 20px;
            // vertical-align: top;
          }
        }

        .Text-details {
          color: rgba(84, 84, 84, 1);
          font-size: 16px;
          line-height: 23px;
          span {
            margin: 0px 5px 0 0;
            display: inline-block;
            // max-width: 600px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
      }
    }
    .MapMsg {
      float: left;
      width: 259px;
      height: 160px;
      // background-color: pink;
      margin-left: 15px;
      overflow: hidden;
      position: relative;
      img {
        width: 100%;
      }
      .map-btn{
        width: 16px;
        height: 16px;
        position: absolute;
        right: 0;
        bottom: 0;
        // background-color: peru;
        background: url("../../assets/img/showMap.png") no-repeat center;
        background-size: 100% 100%;
        cursor: pointer;
      }
    }
    .map-big{
      height: 460px;
    }
    .PdfMsg {
      float: left;
      // line-height: 164px;
     margin-top: 60px;
      margin-left: 15px;
    }
  }
  .content-Box {
    width: 100%;
    min-height: 350px;
    padding: 20px 30px 42px 30px;
    // 上右下左内边距
    box-sizing: border-box;
    margin-top: 15px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 2px 4px 0px rgba(199, 199, 199, 0.5);
    border: 1px solid rgba(239, 239, 239, 1);
    .btn-List {
      text-align: center;
    }
    .Tab-list {
      width: 100%;
      min-height: 200px;
      margin-top: 45px;
      .tabTitle {
        p {
          color: rgba(0, 109, 235, 1);
          font-size: 18px;
          font-weight: 700;
        }
      }
      .tab-table {
        width: 100%;
        border-left: 1px solid rgba(204, 204, 204, 1);
        border-top: 1px solid rgba(204, 204, 204, 1);
        margin-top: 15px;
        // background-color: pink;
        table {
          width: 100%;
          tr {
            width: 100%;
            height: 45px;
            td {
              border-right: 1px solid rgba(204, 204, 204, 1);
              border-bottom: 1px solid rgba(204, 204, 204, 1);
              padding: 15px;
              box-sizing: border-box;
              font-size: 14px;
              color: rgba(153, 153, 153, 1);
              // border-left: 1px solid rgba(204, 204, 204, 1);
            }
          }
        }
      }
    }
  }
}
.container .content-Box .Tab-list .tab-table table tr td.color84 {
  color: rgba(84, 84, 84, 1);
}
    .nothing {
      width: 100%;
      height: 200px;
      padding:20px;
      box-sizing: border-box;
      text-align: center;
      span {
        font-size: 24px;
        color: rgba(84, 84, 84, 1);
        display: inline-block;
        vertical-align: middle;
        line-height: 200px;
         font-weight: 700;  
      }
      img {
        vertical-align: middle;
      }
    }
</style>