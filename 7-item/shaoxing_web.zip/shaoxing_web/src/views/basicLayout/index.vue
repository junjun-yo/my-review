<template>
  <div class="out-main">
    <div class="main">
      <el-header></el-header>
      <!-- <banner></banner> -->
      <el-main>
        <!-- <div class="btns">
          <div v-for="(item) in btns" class="btn-box">
            <el-button type="primary"  size="small" @click="btngo(item.url)">{{item.txt}}</el-button> 
            </div>
        </div>-->
        <router-view />
      </el-main>
      <el-footer></el-footer>
    </div>
  </div>
</template>
<script>
import header from "../../components/header";
import footer from "../../components/footer";
export default {
  data() {
    return {
      btns: [
        {
          txt: "监测站",
          url: "/Home/Monitor"
        },
        {
          txt: "园区分局"
        },
        {
          txt: "监察大队"
        },
        {
          txt: "法规科"
        },
        {
          txt: "固废中心"
        },
        {
          txt: "气科"
        },
        {
          txt: "水科"
        },
        {
          txt: "环境科"
        },
        {
          txt: "环境科"
        }
      ]
    };
  },
  components: {
    "el-header": header,
    "el-footer": footer
  },
  methods: {
    btngo(url) {
      this.$router.push(url);
    }
  },

};
</script>
<style  lang="less" scoped>
.btns {
  width: 900px;
  padding: 0 50px;
  height: 100px;
  margin: 0 auto;
  background-color: pink;
  .btn-box {
    display: inline-block;
    margin-right: 30px;
  }
  .btn-bx:last-child {
    margin-right: 0;
  }
}
.el-main {
  padding: 0 !important;
}
</style>