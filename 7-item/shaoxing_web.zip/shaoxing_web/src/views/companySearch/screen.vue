<template>
    <div class="container">
        <!-- 高级筛选 -->
        <div class="screen-Condition screen-Tab">
            <div class="condition-Header tab-title">
                <span>高级筛选</span>
            </div>
            <div class="condition-content">
                <!-- <div class="content-listItem" v-for="(item,index) in screenList" :key="index">
          <div class="listItem-title">{{item.title}}</div>
          <div class="list-item">
            <span
              v-for="(v,i) in item.list"
              :key="i"
              :class="v.active ? 'condition-Acitve' : ''"
              @click="conditionSearch(i,index)"
            >{{v.name}}</span>
          </div>
                </div>-->
                <div class="content-listItem">
                    <div class="listItem-title">成立时间</div>
                    <div class="list-item">
                        <span
                            :class="item.id == setUpType ? 'condition-Acitve' : ''"
                            v-for="(item,index) in establish"
                            :key="index"
                            @click="conditionSearch(item,index,establish,'setUpType')"
                        >{{item.name}}</span>
                    </div>
                </div>
                <div class="content-listItem">
                    <div class="listItem-title">注册资本</div>
                    <div class="list-item">
                        <span
                            :class="item.id == registCapital ? 'condition-Acitve' : ''"
                            v-for="(item,index) in capital"
                            :key="index"
                            @click="conditionSearch(item,index,capital,'registCapital')"
                        >{{item.name}}</span>
                    </div>
                </div>
                <div class="content-listItem">
                    <div class="listItem-title">企业状态</div>
                    <div class="list-item">
                        <span
                            :class="item.id == status ? 'condition-Acitve' : ''"
                            v-for="(item,index) in enterprise"
                            :key="index"
                            @click="conditionSearch(item,index,enterprise,'status')"
                        >{{item.name}}</span>
                    </div>
                </div>
                <div class="content-listItem">
                    <div class="listItem-title">行业分类</div>
                    <div class="list-item">
                        <span
                            :class="item.id == industry ? 'condition-Acitve' : ''"
                            v-for="(item,index) in Industry"
                            :key="index"
                            @click="conditionSearch(item,index,Industry,'industry')"
                        >{{item.name}}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="screen-Result screen-Tab">
            <div class="tab-title">
                <span>
                    找到
                    <i class="num">{{total}}</i>条相关结果
                </span>
            </div>
            <div class="Result-box">
                <div
                    class="Result-content"
                    v-for="(item,index) in list"
                    :key="index"
                    @click="goCompanyMsg(item.creditCode)"
                >
                    <div class="ResultMsg">
                        <div class="ResultMsg-Img">
                            <img src="@/assets/img/company.png" alt />
                        </div>
                        <div class="ResultMsg-Text">
                            <p>{{item.companyName}}</p>
                            <!-- 企业的名称 -->
                            <div class="Text-details">
                                <span>法定代表人：{{item.legalPerson}}</span>
                                <span>注册资本：{{item.registCapital}}</span>
                                <span>成立时间：{{item.setUpTime}}</span>
                            </div>
                            <div class="Text-details">
                                <span>联系人：{{item.contactor}}</span>
                                <span>电话：{{item.tel}}</span>
                            </div>
                            <div class="Text-details">
                                <span>地址：{{item.address}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="ResultBtn">
                        <button v-if="item.operateStatus==='存续'" class="small-button greenBorder">存续</button>
                        <button
                            v-else-if="item.operateStatus==='注销'"
                            class="small-button redBorder"
                        >注销</button>
                        <button
                            v-else-if="item.operateStatus==='迁出'"
                            class="small-button greyBorder"
                        >迁出</button>
                        <button
                            v-else-if="item.operateStatus==='吊销-已注销'"
                            class="small-button greyBorder"
                        >吊销-已注销</button>
                        <button
                            v-else-if="item.operateStatus==='吊销-未注销'"
                            class="small-button greyBorder"
                        >吊销-未注销</button>
                    </div>
                </div>
                <div class="condition-page">
                    <el-pagination
                        background
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="curPage"
                        layout="total,prev, pager, next,jumper"
                        :page-size="showCount"
                        :total="sum"
                    ></el-pagination>
                </div>
                <!-- 分页模块 -->
            </div>
            <!-- <div class="nothing" v-else>
        <img src="../../assets/img/Group 8.png" alt />
        <span>没有找到相关企业</span>
            </div>-->
        </div>
    </div>
</template>
<script>
import Apis from "../../api/home";
import { bus } from "../../utils/bus";

export default {
    data() {
        return {
            showCount: 10,
            // 每页显示10条数据，默认
            curPage: 1,
            // 默认显示第一页数据
            total: 0,

            sum: 0,
            // status:'',
            message: '',

            companyName: '绍兴',
            currentPage4: 1,
            content: {
                time: [],
                amount: [],
                status: [],
                type: []
            },
            screenList: [
                {
                    title: "成立时间",
                    list: [
                        {
                            name: "全部",
                            id: '',
                            active: true
                        },
                        {
                            name: "成立1年内",
                            id: 1,
                            active: false
                        },
                        {
                            name: "成立1-5年内",
                            id: 2,
                            active: false
                        },
                        {
                            name: "成立5-10年内",
                            id: 3,
                            active: false
                        },
                        {
                            name: "成立10-15年内",
                            id: 4,
                            active: false
                        },
                        {
                            name: "成立15年内",
                            id: 5,
                            active: false
                        }
                    ]
                },
                {
                    title: "注册资本",
                    list: [
                        {
                            name: "全部",
                            id: '',
                            active: true
                        },
                        {
                            name: "0-100万",
                            id: 1,
                            active: false
                        },
                        {
                            name: "100-200万",
                            id: 2,
                            active: false
                        },
                        {
                            name: "200-500万",
                            id: 3,
                            active: false
                        },
                        {
                            name: "500-1000万",
                            id: 4,
                            active: false
                        },
                        {
                            name: "1000万以上",
                            id: 5,
                            active: false
                        }
                    ]
                },
                {
                    title: "企业状态",
                    list: [
                        {
                            name: "全部",
                            id: '',
                            active: true
                        },
                        {
                            name: "存续",
                            id: '存续',
                            active: false
                        },
                        {
                            name: "吊销-未注销",
                            // id: '吊销-未注销',
                            id: '注销',
                            active: false
                        },
                        {
                            name: "吊销-已注销",
                            // id: '吊销-已注销',
                            id: '注销',
                            active: false
                        },
                        {
                            name: "注销",
                            id: '注销',
                            active: false
                        },
                        {
                            name: "迁出",
                            // id: '迁出',
                            id: '注销',
                            active: false
                        }
                    ]
                },
                {
                    title: "行业分类",
                    list: [
                        {
                            name: "全部",
                            id: '',
                            active: true
                        },
                        {
                            name: "化工",
                            id: '化工',
                            active: false
                        },
                        {
                            name: "食品加工",
                            id: '食品加工',
                            active: false
                        },
                        {
                            name: "医药",
                            id: '医药',
                            active: false
                        },
                        {
                            name: "重金属",
                            id: '重金属',
                            active: false
                        },
                        {
                            name: "纺织",
                            id: '纺织',
                            active: false
                        },
                        {
                            name: "其他",
                            id: '其他',
                            active: false
                        }
                    ]
                }
            ],
            establish: "",
            capitalValue: "",
            enterpriseValue: "",
            IndustryValue: "",
            establish: [
                {
                    name: "全部",
                    id: "",
                    active: true
                },
                {
                    name: "成立1年内",
                    id: 1,
                    active: false
                },
                {
                    name: "成立1-5年内",
                    id: 2,
                    active: false
                },
                {
                    name: "成立5-10年内",
                    id: 3,
                    active: false
                },
                {
                    name: "成立10-15年内",
                    id: 4,
                    active: false
                },
                {
                    name: "成立15年内",
                    id: 5,
                    active: false
                }
            ],
            capital: [
                {
                    name: "全部",
                    id: "",
                    active: true
                },
                {
                    name: "0-100万",
                    id: 1,
                    active: false
                },
                {
                    name: "100-200万",
                    id: 2,
                    active: false
                },
                {
                    name: "200-500万",
                    id: 3,
                    active: false
                },
                {
                    name: "500-1000万",
                    id: 4,
                    active: false
                },
                {
                    name: "1000万以上",
                    id: 5,
                    active: false
                }
            ],
            enterprise: [
                {
                    name: "全部",
                    id: "",
                    active: true
                },
                {
                    name: "续存",
                    id: "续存",
                    active: false
                },
                {
                    name: "吊销-未注销",
                    id: "吊销-未注销",
                    // id: "注销",
                    active: false
                },
                {
                    name: "吊销-已注销",
                    id: "吊销-已注销",
                    // id: "注销",
                    active: false
                },
                {
                    name: "注销",
                    id: "注销",
                    active: false
                },
                {
                    name: "迁出",
                    id: "迁出",
                    // id: "注销",
                    active: false
                }
            ],
            Industry: [
                {
                    name: "全部",
                    id: "",
                    active: true
                },
                {
                    name: "化工",
                    id: "化工",
                    active: false
                },
                {
                    name: "食品加工",
                    id: "食品加工",
                    active: false
                },
                {
                    name: "医药",
                    id: "医药",
                    active: false
                },
                {
                    name: "金属",
                    id: "金属",
                    active: false
                },
                {
                    name: "纺织",
                    id: "纺织",
                    active: false
                },
                {
                    name: "其他",
                    id: "其他",
                    active: false
                }
            ],

            list: [
                {
                    id: 1
                }

            ],
            setUpType: '',
            registCapital: '',
            industry: '',
            status: '',

        };
    },
    created() {
        let that = this;
        this.getInformation2()
        // 立即调用
        bus.$on('search', function (msg) {
            that.getInformation2();
        })
    }
    ,
    beforeDestroy() {
        // 销毁监听事件
        bus.$off('query');
    },
    watch: {
        '$route': function (to, from) {

            this.getInformation2();
        }
        //  执行数据更新查询
    },
    methods: {
        conditionSearch(item, index, value, name) {
            this[name] = item.id
            this.getInformation2();
            // value.forEach(i => {
            //   i.active = false;
            // });
            // item.active = true;
            // this[name]=item.name;
            // let querystring={
            //   companyName:this.companyName,
            //   setUpType:this.setUpType,
            //   registCapital:this.registCapital,
            //   status:this.status,
            //   industry:this.industry
            // }
            // this.bus.$emit('query',JSON.stringify(querystring));
        },

        goCompanyMsg(id) {

            this.$router.push('/basicInformation/' + id)

        },
        getInformation2() {

            // 企业基本信息查询

            this.companyName = this.$route.query.seat;
            let value = {
                companyName: this.companyName,
                setUpType: this.setUpType,
                registCapital: this.registCapital,
                status: this.status,
                industry: this.industry,
                showCount: this.showCount,
                curPage: this.curPage
            };
            if(this.status == '吊销-未注销' || this.status == '吊销-已注销' || this.status == '迁出'){
              value.status = '注销'
            }
            // 传递给后端的数据
            Apis.companyBasicInfoList(value).then(res => {
                if (res.code == 200) {
                    this.list = res.data.queryCompanyInfo.data;
                    // console.log(res);


                    this.total = res.data.queryCompanyInfo.totalPage;
                    this.sum = res.data.queryCompanyInfo.totalResult

                } else {
                    this.$message({
                        type: "error",
                        message: res.message
                    });
                }
            }).catch(error => {
                console.log(error)
            });
        },
        handleSizeChange(newSize) {

            this.showCount = newSize,
                this.getInformation2()
        },
        // 监听pagesize变化                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
        handleCurrentChange(newPage) {
            this.curPage = newPage,
                this.getInformation2()
        }
        // 监听页码值的变化
    }
};
</script>
<style lang="less" scoped>
.container {
    .screen-Condition {
        height: 250px;
        .condition-content {
            padding: 20px;
            box-sizing: border-box;
            font-size: 14px;
            height: 100%;
            .content-listItem {
                .listItem-title {
                    color: rgba(153, 153, 153, 1);
                    width: 66px;
                    border-right: 1px solid rgba(240, 240, 240, 1);
                    display: inline-block;
                }
                .list-item {
                    display: inline-block;
                    margin-bottom: 20px;
                    cursor: pointer;
                    span {
                        display: inline-block;
                        padding: 0 20px;
                        color: rgba(84, 84, 84, 1);
                    }
                    span:hover {
                        color: rgba(31, 126, 237, 1);
                    }
                    .condition-Acitve {
                        color: rgba(0, 109, 235, 1);
                    }
                }
            }
        }
    }
    .screen-Result {
        min-height: 300px;
        .Result-content {
            width: 100%;
            height: 190px;
            padding: 35px;
            box-sizing: border-box;
            background: rgba(255, 255, 255, 1);
            box-shadow: 1px 0px 0px 1px rgba(240, 240, 240, 1);
            border: 1px solid rgba(239, 239, 239, 1);
            cursor: pointer;
            .ResultMsg {
                float: left;
                .ResultMsg-Img {
                    float: left;
                    width: 130px;
                    height: 130px;
                    border-radius: 8px;
                    overflow: hidden;
                    img {
                        width: 100%;
                    }
                }
                .ResultMsg-Text {
                    float: left;
                    margin-left: 20px;
                    height: 130px;
                    p {
                        font-size: 18px;
                        font-weight: 700;
                        margin-bottom: 35px;
                        color: rgba(51, 51, 51, 1);
                        max-width: 600px;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                    .Text-details {
                        color: rgba(84, 84, 84, 1);
                        font-size: 16px;
                        line-height: 22px;
                        span {
                            margin: 0px 10px;
                            display: inline-block;
                            max-width: 600px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                        }
                    }
                }
            }
            .ResultBtn {
                float: right;
                line-height: 120px;
            }
        }
        .nothing {
            width: 100%;
            height: 359px;
            text-align: center;
            span {
                font-size: 24px;
                color: rgba(84, 84, 84, 1);
                display: inline-block;
                vertical-align: middle;
                line-height: 359px;
                margin-left: 20px;
                font-weight: 700;
            }
            img {
                vertical-align: middle;
            }
        }
    }
    .condition-page {
        width: 100%;
        height: 150px;
        background-color: rgba(255, 255, 255, 1);
        text-align: center;
        padding: 59px 0;
        box-sizing: border-box;
    }
}
.screen-Tab {
    width: 1160px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 2px 4px 0px rgba(199, 199, 199, 0.5);
    border: 1px solid rgba(239, 239, 239, 1);
    margin-top: 15px;
    .tab-title {
        height: 50px;
        background: rgba(252, 252, 252, 1);
        box-shadow: 0px 1px 0px 0px rgba(240, 240, 240, 1);
        padding: 0 17px;
        box-sizing: border-box;
        span {
            color: rgba(84, 84, 84, 1);
            display: inline-block;
            line-height: 50px;
        }
        .num {
            color: rgba(0, 109, 235, 1);
            margin: 0 5px;
        }
    }
}
.Result-content:hover {
    background-color: rgba(237, 245, 255, 1) !important;
    .ResultMsg-Text {
        p {
            color: rgba(31, 126, 237, 1) !important;
        }
    }
}
</style>