<template>
  <div>
    <banner></banner>
    <div class="img-box">
      <div class="img-content">
        <div class="tab-box">
          <el-button
            v-for="(item,index) in btns"
            :key="index"
            :type="item.active ? 'primary ':'null'"
            @click="changeTab(index)"
          >{{item.value}}</el-button>
        </div>
        <div class="list-item">
          <div
            class="card"
            v-for="(item,index) in list"
            :key="index"
            @click="goSystem(item.sysUrl)"
          >
            <img src="@/assets/img/test.png" alt="img" />
            <div class="card-content">
              <span class="left">{{item.sysName}}</span>
              <span class="right el-icon-arrow-right"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Apis from "../../api/home";
import banner from "../../components/banner";
export default {
  data() {
    return {
      activeBtn: 1,
      btns: [
        {
          value: "监测站",
          type: 1,
          active: true
        },
        {
          value: "园区分局",
          type: 2,
          active: false
        },
        {
          value: "监察大队",
          type: 3,
          active: false
        },
        {
          value: "法规科",
          type: 4,
          active: false
        },
        {
          value: "固废中心",
          type: 5,
          active: false
        },
        {
          value: "气科",
          type: 8,
          active: false
        },
        {
          value: "水科",
          type: 6,
          active: false
        },
        {
          value: "环境科",
          type: 7,
          active: false
        },
        {
          value: "其他",
          type: 9,
          active: false
        }
      ],
      list: [
        // {
        //   sysName: "大屏一期大屏一期大屏一期大屏一期大屏一期大屏一期大屏一期大屏一期",
        //   sysUrl: "@/assets/img/test.png"
        // },
      ],
      tabKey: ""
    };
  },
  created() {
    this.getgetSystemList();
  },
  methods: {
    getgetSystemList() {
      let input = {
        type: this.activeBtn
      };
      Apis.getSystemInfo(input)
        .then(res => {
          if (res.code == 200) {
            this.list = res.data.queryPortalSystemOutPut;
          } else {
            this.$message({
              type: "error",
              message: res.message
            });
          }
        })
        .catch(erro => {
          console.log(erro);
        });
    },
    changeTab(key) {
      this.btns.forEach(item => {
        item.active = false;
      });
      this.btns[key].active = true;
      this.activeBtn = this.btns[key].type;
      this.getgetSystemList();
    },
    goSystem(url) {
      window.location.href = url;
    }
  },
  components: {
    banner
  }
};
</script>

<style lang="less">
.img-box {
  width: 100%;
  .img-content {
    width: 1160px;
    margin: 0 auto;
    height: 800px;
    .tab-box {
      text-align: center;
      padding: 40px 80px;
    }
    .list-item {
      .card {
        width: 255px;
        height: 280px;
        background: rgba(255, 255, 255, 1);
        border-radius: 4px;
        border: 1px solid rgba(230, 230, 230, 1);
        padding: 13px;
        box-sizing: border-box;
        margin-right: 46.5px;
        margin-bottom: 40px;
        float: left;
        cursor: pointer;
        img {
          display: block;
          margin: 0 auto;
          width: 230px;
          height: 160px;
          border-radius: 4px;
        }
        .card-content {
          margin-top: 20px;
          height: 60px;
          width: 230px;
          // background-color: pink;
          .left {
            float: left;
            font-size: 16px;
            font-weight: 400;
            color: rgba(84, 84, 84, 1);
            // background-color: red;
            max-width: 200px;
            line-height: 30px;
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
          }
          .right {
            float: right;
            // background-color: blue;
            line-height: 30px;
          }
        }
      }
      .card:nth-of-type(4n) {
        margin-right: 0;
      }
      .card:hover {
        box-shadow: 0px 6px 7px 0px rgba(206, 206, 206, 0.5);

      }
    }
  }
}
</style>
<style>
.img-box .el-button {
  margin-left: 20px;
}
</style>
