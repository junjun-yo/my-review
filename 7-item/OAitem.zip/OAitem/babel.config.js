module.exports = {
  presets: ["@vue/app"],
  ignore: ["./public/ueditor/*.js"]
};
