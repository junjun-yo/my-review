const router = [
    {
        path: "category",
        name: "category",
        component: resolve =>
            require(["views/export/addressBookCategory/index"], resolve),
        meta: { title: "通讯录组", icon: "icon-tickets" }
    }
];

export default router;
