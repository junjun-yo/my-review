const router = [
    {
        path: "addressBook",
        name: "addressBook",
        component: resolve =>
            require(["views/export/addressBook/index"], resolve),
        meta: { title: "通讯录", icon: "icon-tickets" }
    }
];

export default router;
