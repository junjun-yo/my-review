<template>
    <el-container style="height: 100%;">
        <el-main>
            <el-card class="full-card" shadow="never" style="overflow-y: auto;">
                <oa-table
                        v-loading="loading"
                        ref="table"
                        :ajax="ajaxParams"
                        :columns="columns"
                        showToolbar
                        showPage
                        :more="false"
                        keywordTxt="标题检索"
                        :adjustHeight="-50"
                        :showTooltip="true"
                        :sort="['instanceLevel','flowName','instanceTitle','createDate']"
                >
                    <template slot-scope="{queryForm}" slot="more">
                        <!--<el-form-item label="自定义扩展查询">-->
                        <!--<el-input v-model="queryForm.abc" placeholder="自定义扩展查询"></el-input>-->
                        <!--</el-form-item>-->
                        <!--<el-form-item label="自定义扩展查询">-->
                        <!--<el-input v-model="queryForm.edf" placeholder="自定义扩展查询"></el-input>-->
                        <!--</el-form-item>-->
                    </template>
                    <!--<template slot-scope="{btns}" slot="btns">-->
                    <!--</template>-->
                    <template slot-scope="{row,col}" slot="render">
                        <el-tag v-if="col.prop=='instanceLevel'" :type="renderLevel(row.instanceLevel)">
                            {{row.instanceLevel|dict('instanceLevel')}}
                        </el-tag>
                        <el-link type="primary" v-if="col.prop=='instanceTitle'" @click="showDetails(row)">
                            {{row.instanceTitle}}
                        </el-link>
                        <el-button-group v-if="col.prop=='btns'">
                            <el-button type="text" v-if="!row.lastTask" @click="deleteInstance(row)">删除</el-button>
                        </el-button-group>
                    </template>
                </oa-table>
            </el-card>
        </el-main>
    </el-container>
</template>

<script>
    import store from "@/store";
    import workflowNode from "../node";
    import workflowForm from "../components/form"

    export default {
        created() {
            this.ajaxParams.params.flowType = this.$route.params.flowType;
        },
        data() {
            return {
                store,
                workflowNode,
                loading: false,
                ajaxParams: {
                    url: "/flow/task/pending",
                    method: "post",
                    params: {
                        assignee: store.state.account.sysUser.userId,
                        createUnit: store.state.account.sysUser.unitId,
                        flowType: "",
                        keyword: ""
                    }
                },
                columns: [
                    {
                        label: "紧急程度",
                        prop: "instanceLevel",
                        align: "center",
                        width: "110px",
                        render: true
                        // fmt: row => {
                        //     return this.$options.filters["dict"](row.instanceLevel,"instanceLevel");
                        // }
                    },
                    {
                        label: "标题",
                        prop: "instanceTitle",
                        render: true
                    },
                    {
                        label: "流程名称",
                        prop: "flowName"
                    },
                    {
                        label: "发送人",
                        prop: "createUserName",
                        align: "center",
                        width: "100px"
                    },
                    {
                        label: "接收时间",
                        prop: "createDate",
                        width: "160px",
                        align: "center",
                        fmt: row => {
                            return this.$options.filters["date"](row.createDate, "yyyy-MM-dd hh:mm:ss");
                        }
                    },
                    {
                        label: "处理动作",
                        prop: "stepName",
                        align: "center"
                    },
                    {
                        label: "状态",
                        width: "100px",
                        align: "center",
                        prop: "taskStatus",
                        fmt: row => {
                            return this.workflowNode.filter("taskStatus", row.taskStatus);
                        }
                    },
                    {
                        label: "操作",
                        align: "center",
                        width: "140px",
                        prop: "btns",
                        render: true
                        // opts: [
                        //     {
                        //         title: "删除",
                        //         click: this.deleteRow
                        //     }
                        // ]
                    }
                ]
            };
        },
        methods: {
            renderLevel(level) {
                let str = "success";
                switch (level) {
                    case "1":
                        str = "success";
                        break;
                    case "2":
                        str = "warning";
                        break;
                    case "3":
                        str = "danger";
                        break;
                }
                return str;
            },
            showDetails(item) {console.log(item);
                this.$open({
                    title: item.instanceTitle ? item.instanceTitle : "流程表单",
                    component: workflowForm,
                    // width: "100%",
                    // height: "100%",
                    fullScreen: true,
                    showConfirmBtn: false,
                    showCloseBtn: false,
                    showClose: true,
                    props: {
                        instanceId: item.instanceId,
                        taskId: item.id,
                        flowId: item.flowId,
                        formId: item.formId,
                        fmId: item.fmId,
                        stepKey: item.stepKey
                    },
                    confirm: () => {
                        this.$refs.table.reload();
                    }
                });
            },
            deleteInstance(item) {
                this.$confirm("是否删除[" + item.instanceTitle + "]?", "提示", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    this.loading = true;
                    Ajax.delete("/flow/task/removeInstance", {
                        instanceId: item.instanceId,
                    }).then(res => {
                        this.loading = false;
                        this.$message.success("删除成功");
                        this.$refs.table.reload();
                    }).catch(err => {
                        this.loading = false;
                    });
                });
            }
        }
    };
</script>

<style lang='scss' scoped>
</style>