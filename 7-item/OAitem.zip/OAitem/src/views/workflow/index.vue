<template>
  <el-container style="height: 100%;">
    <el-aside width="220px">
      <el-row style="height: 100%;">
        <el-col :span="24">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>流程类型</span>
            </div>
            <el-collapse v-model="activeName" accordion>
              <el-collapse-item
                :title="item.value"
                :name="item.key"
                v-for="(item,index) in store.state.dict.dict.flowType"
              >
                <div class="subType">
                  <el-link
                    :type="curType(item) ? 'primary' : 'default'"
                    @click="setFlowType(item)"
                  >所有子类</el-link>
                </div>
                <div
                  class="subType"
                  v-for="subtype in subTypes"
                  v-if="subtype.flowType == item.key"
                >
                  <el-link
                    :type="curType(item,subtype) ? 'primary' : 'default'"
                    @click="setFlowType(item,subtype)"
                  >{{subtype.name}}</el-link>
                </div>
              </el-collapse-item>
            </el-collapse>
          </el-card>
        </el-col>
      </el-row>
    </el-aside>
    <el-main>
      <el-row style="height: 100%;">
        <el-col :span="24">
          <el-card class="full-card" shadow="never">
            <div slot="header" class="clearfix card-header">
              <el-row>
                <el-col :span="24">
                  <el-input
                    placeholder="名称 | 标识"
                    v-model="ajaxParams.params.keyword"
                    :style="{width:'420px',float:'left'}"
                    class="input-with-select"
                  >
                    <template slot="prepend">{{ajaxParams.params.flowType|dict('flowType')}}</template>
                    <el-button
                      type="primary"
                      slot="append"
                      icon="el-icon-search"
                      plain
                      @click="()=>{this.$refs.table.reload()}"
                    ></el-button>
                  </el-input>
                  <el-button-group style="float: right; ">
                    <el-button
                      type="primary"
                      icon="el-icon-plus"
                      v-if="addOk()==true"
                      plain
                      @click="addFunc"
                    >创建流程</el-button>
                  </el-button-group>
                </el-col>
              </el-row>
            </div>
            <oa-table
              :ajax="ajaxParams"
              :columns="columns"
              showPage
              @check="onCheck"
              :adjustHeight="-70"
              :sort="['flowName','flowStatus','flowType']"
              :add="addFunc"
              ref="table"
            ></oa-table>
          </el-card>
        </el-col>
      </el-row>
    </el-main>
  </el-container>
</template>

<script>
import design from "./components/design";
import store from "@/store";
export default {
  created() {
    this.ajaxParams.params.createUnit = store.state.account.sysUser.unitId;
  },
  data() {
    return {
      deptTreeDatas: [],
      store,
      subTypes: [],
      curSubType: "",
      ajaxParams: {
        url: "/flow/definition/page",
        method: "post",
        params: {
          createUnit: "",
          flowStatus: "",
          flowType: "01",
          subTypeId: "",
          keyword: ""
        }
      },
      columns: [
        {
          label: "流程标识",
          prop: "flowKey"
        },
        {
          label: "流程名称",
          prop: "flowName"
        },
        {
          label: "流程类型",
          prop: "flowType",
          align: "center",
          width: "120px",
          fmt: row => {
            return this.$options.filters["dict"](row.flowType, "flowType");
          }
        },
        {
          label: "流程状态",
          prop: "flowStatus",
          align: "center",
          width: "120px",
          fmt(row) {
            let str = "";
            switch (row.flowStatus) {
              case "0":
                str = "停用";
                break;
              case "1":
                str = "启用";
                break;
              case "2":
                str = "过期";
                break;
            }
            return str;
          }
        },
        {
          label: "版本号",
          prop: "versionNo",
          align: "center",
          width: "80px"
        },
        {
          label: "操作",
          align: "center",
          width: "160px",
          opts: [
            {
              title: "激活",
              click: (row, index) => {
                this.setState(row.id, "1");
              },
              hide: (row, index) => {
                return row.flowStatus == "1";
              }
            },
            {
              title: "停用",
              click: (row, index) => {
                this.setState(row.id, "0");
              },
              hide: (row, index) => {
                return row.flowStatus == "0";
              }
            },
            {
              title: "设计",
              click: this.editRow
            },
            {
              title: "删除",
              click: this.deleteRow
            }
          ]
        }
      ],
      activeName: "01"
    };
  },
  methods: {
    onCheck(checks) {
      console.log(checks);
    },
    addFunc() {
      this.$open({
        title: "新建流程",
        fullScreen: true,
        component: design,
        confirmText: "保存",
        closeText: "关闭",
        props: {
          unitId: this.ajaxParams.params.createUnit,
          flowType: this.ajaxParams.params.flowType,
          subTypeId: this.ajaxParams.params.subTypeId
        },
        confirm: () => {
          this.$refs.table.reload();
        }
      });
    },
    editRow(row, index) {
      this.$open({
        title: "编辑" + row.flowName,
        fullScreen: true,
        component: design,
        confirmText: "保存",
        closeText: "关闭",
        props: {
          id: row.id,
          unitId: row.createUnit,
          flowType: row.flowType,
          subTypeId: row.subTypeId
        },
        confirm: () => {
          this.$refs.table.reload();
        }
      });
    },
    deleteRow(row, index) {
      this.$confirm(
        "是否删除流程[" + row.flowName + "]?已经创建了实例的流程请不要删除！",
        "提示",
        {
          type: "warning"
        }
      ).then(() => {
        Ajax.delete("/flow/definition/delete", {
          id: row.id
        }).then(res => {
          if (res.success) {
            this.$message.success("删除成功");
            this.$refs.table.reload();
          }
        });
      });
    },
    setFlowType(item, subtype) {
      this.ajaxParams.params.flowType = item.key;
      if (subtype && subtype.id) {
        this.ajaxParams.params.subTypeId = subtype.id;
        this.curSubType = subtype.name;
      } else {
        this.ajaxParams.params.subTypeId = "";
        this.curSubType = "";
      }
    },
    querySubType() {
      Ajax.post("/flow/subType/list", {
          unitId : store.state.account.sysUser.unitId
      }).then(res => {
        this.subTypes = res.data;
      });
    },
    curType(item, subtype) {
      if (this.ajaxParams.params.flowType == item.key) {
        if (subtype && subtype.id == this.ajaxParams.params.subTypeId) {
          return true;
        } else {
          return (
            !subtype &&
            (!this.ajaxParams.params.subTypeId ||
              this.ajaxParams.params.subTypeId == "")
          );
        }
      } else {
        return false;
      }
    },
    setState(flowId, state) {
      Ajax.put("/flow/definition/setState", {
        id: flowId,
        state: state
      }).then(res => {
        // this.$message({
        //     message: "操作成功！",
        //     type: "success"
        // });
        this.$refs.table.reload();
      });
    },
    addOk() {
      return (
        this.ajaxParams.params.createUnit &&
        this.ajaxParams.params.createUnit != "" &&
        this.ajaxParams.params.flowType &&
        this.ajaxParams.params.flowType != ""
      );
    }
  },
  mounted() {
    this.querySubType();
  }
};
</script>

<style lang='scss' scoped>
.subType {
  padding-left: 20px;
  line-height: 35px;
}
</style>