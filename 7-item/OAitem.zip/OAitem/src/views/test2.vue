<template>
  <div style="height:100%;width:100%;">
    <workflow-design />
  </div>
</template>

<script>
import WorkflowDesign from "@/components/WorkflowDesign";

export default {
  components: {
    WorkflowDesign
  },
  data() {
    return {};
  }
};
</script>

<style lang='scss' scoped>
</style>