<template>
    <div style="margin-top:10px;margin-left: 20px"  >
        <el-button type="primary" @click="send()">发送</el-button>
        <el-button type="primary" @click="saveToDraftBox()">存草稿</el-button>
        <el-divider></el-divider>
        <div style="margin-top: 10px">
            <el-form :model="mailForm" label-position="right" :rules="rules" ref="mail" :loading="loading">

                <el-form-item label="接收人" prop="CCReceiverIds">
                    <div style="float: left;width: 600px">
                        <user-select  v-model="mailForm.CCReceiverIds" />
                    </div>
                    <div style="float:left;margin-left: 150px">
                        <el-button @click="changeWCCType()">添加抄送</el-button>
                        <el-button @click="changeBCCType()">添加密送</el-button>
                    </div>
                    <div style="clear: both"></div>
                </el-form-item>

                <el-form-item label="抄送人" v-if="WCC?true:false"  prop="WCCReceiverIds">
                    <user-select style="width:600px"  v-model="mailForm.WCCReceiverIds" />
                </el-form-item>

                <el-form-item label="密送人"  v-if="BCC?true:false" prop="BCCReceiverIds">
                    <user-select style="width:600px"   v-model="mailForm.BCCReceiverIds" />
                </el-form-item>

                <el-form-item label="主  题" prop="title">
                    <el-input  style="margin-left:10px;width:600px" placeholder="请输入主题"  v-model="mailForm.title"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-link type="primary" style="margin-left: 50px">附件上传</el-link>
                </el-form-item>
                <el-form-item label="正文" style="margin-left: 50px">
                    <UE :config="config" ref="ue"></UE>
                </el-form-item>

                <el-form-item style="margin-left: 50px" prop="importance">
                    <el-checkbox-group v-model="mailForm.importance">
                        <el-checkbox label="1">重要</el-checkbox>
                        <el-checkbox label="2">回执</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
            </el-form>
            <div style="margin-left: 50px">
                <el-button type="primary" @click="send()">发送</el-button>
                <el-button type="primary" @click="saveToDraftBox()">存草稿</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    import UE from "../../write_mail/component/ueditor"
    export default {
        components:{UE},
        data(){
            return {
                BCC:false,
                WCC:false,
                loading:false,
                mailForm:{
                    senderId : this.$store.state.account.sysUser.userId,
                    WCCReceiverIds:"",
                    BCCReceiverIds:"",
                    CCReceiverIds:"",
                    importance:[]
                },
                rules:{
                    CCReceiverIds:[
                        { required: true, message: '请选择发送人员', trigger: 'blur' },
                    ],
                    WCCReceiverIds:[
                        { required: true, message: '请选择密送人员', trigger: 'blur' },
                    ],
                    BCCReceiverIds:[
                        { required: true, message: '请选择抄送人员', trigger: 'blur' },
                    ],
                    title:[
                        { required: true, message: "请输入主题", trigger: "blur" }
                    ]
                },
                config:{
                    initialFrameWidth:1000,
                    initialFrameHeight:480,
                    elementPathEnabled : false
                },
            }
        },
        methods:{
            changeWCCType(){
                this.WCC=!this.WCC;
            },
            changeBCCType(){
                this.BCC=!this.BCC;
            },
            send(){
                //通过验证后发送
                console.log("发送开始");
                this.loading=false;
                this.$refs.mail.validate(valiad => {
                    if(valiad) {
                        let str="";
                        for(let i=0;i<this.mailForm.importance.length;i++){
                            if(i==this.mailForm.importance.length-1)
                                str += this.mailForm.importance[i];
                            else
                                str  += this.mailForm.importance[i]+",";
                        }
                        this.mailForm.importance = str;
                        this.mailForm.saveType="2";
                        this.mailForm.sendType = "1";
                        this.mailForm.fileSaveType = "1";
                        this.mailForm.content= this.getUEContent();
                        Ajax.put("/mailbox/saveMailInfo",
                            this.mailForm
                        ).then(res =>{
                            this.$message({
                                message:"发送成功",
                                type:"success"
                            });
                            this.$router.push({path:'/mailbox/write_mail1'});
                            this.loading=true;
                            console.log("发送结束");
                        },err => {
                            fail();
                        })
                    }
                })
            },
            saveToDraftBox(){
                //存草稿
                this.$refs.mail.validate(valiad => {
                    if(valiad) {
                        this.mailForm.content= this.getUEContent();
                        Ajax.put("/mailbox/saveMailInfo",
                            this.mailForm
                        ).then(res =>{
                            this.$message({
                                message:"存储成功",
                                type:"success"
                            });
                            this.$refs.mail.reload();
                        },err => {
                            fail();
                        })
                    }
                })
            },
            getUEContent(){
                console.log(this.$refs.ue.getContentHtml());
                return this.$refs.ue.getContentHtml();
            },
            getUEContentTxt(){
                console.log(this.$refs.ue.getContentTxt());
                return this.$refs.ue.getUEContentTxt();
            },
            back(){
                this.$router.push({path:'/mailbox/open_mail',query:{mail:this.$route.query.mail}});
            }
        },
        created() {
            console.log(this.$route.query.mail);
                this.mailForm.CCReceiverIds = this.$route.query.mail.senderId;
                this.mailForm.title = "Re:"+this.$route.query.mail.title;
        }
    }
</script>

<style scoped>

</style>