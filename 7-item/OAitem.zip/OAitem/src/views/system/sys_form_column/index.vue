<template>
    <el-container style="height: 100%;">
        <el-aside width="200px">
            <el-row style="height: 100%;">
                <el-col style="margin-top:10px;margin-left:10px;" :span="20">
                    <a @click="setFlowType({value:'通用',key:'0'})">
                        <el-card style="cursor: pointer;" :shadow="'0' == ajaxParams.params.flowType ? 'always' : 'hover'">
                            通用
                        </el-card>
                    </a>
                </el-col>
                <el-col style="margin-top:10px;margin-left:10px;" :span="20" v-for="(item,index) in store.state.dict.dict.flowType" :key="item.key">
                    <a @click="setFlowType(item)">
                        <el-card style="cursor: pointer;" :shadow="item.key == ajaxParams.params.flowType ? 'always' : 'hover'">{{item.value}}</el-card>
                        <!--<el-card style="cursor: pointer;" v-if="item.key == ajaxParams.params.flowType" shadow="always">{{item.value}}</el-card>-->
                        <!--<el-card style="cursor: pointer;" v-if="item.key != ajaxParams.params.flowType" shadow="hover">{{item.value}}</el-card>-->
                    </a>
                </el-col>
            </el-row>
        </el-aside>
        <el-main>
            <oa-table :ajax="ajaxParams" :columns="columns" showToolbar showPage
                      @check="onCheck" :add="addFunc" ref="table" :more="false" keywordTxt="名字 | 字段名"
                      :sort="['flowType','name','codePrefix','codeYm','codeLen','sort']">
            </oa-table>
        </el-main>
    </el-container>
</template>

<script>
    import formComponent from "./component/form";
    import store from "@/store";
    export default {
        created(){
            this.ajaxParams.params.unitId = store.state.account.sysUser.unitId;
        },
        data() {
            return {
                store,
                //表格异步请求数据参数
                ajaxParams: {
                    url: "/common/form/syscolumn/page",
                    method: "post",
                    params: {
                        keyword : "",
                        flowType : "0",
                        unitId : ""
                    }
                },
                //列头属性配置
                columns: [
                    {label: "排序号",prop: "sort",align: "",width: ""},
                    {
                        label: "所属分类",
                        prop: "flowType",
                        align: "",
                        width: "",
                        fmt:(row)=>{
                            if(row.flowType=='0'){
                                return "通用";
                            }
                            return this.$options.filters["dict"](row.flowType,"flowType");
                        }
                    },
                    { label: "字段名称", prop: "name", align: "", width: ""},
                    { label: "表字段", prop: "columnName", align: "",  width: ""},
                    { label: "类型", prop: "len", align: "",  width: "",
                        fmt:(row)=>{
                            return row.dataType+"["+row.len+","+row.decLen+"]";
                        }
                    },
                    { label: "属性", prop: "dataType", align: "",  width: "",
                        fmt:(row)=>{
                            // return row.isSearch+","+row.notNull;
                            let isSearch = row.isSearch == '1' ? "查询" : "不查询";
                            let notNull = row.notNull == '1' ? "非空" : "可为空";
                            return <div><el-tag type='success' >{isSearch}</el-tag><el-tag type='primary' >{notNull}</el-tag></div>;
                        }
                    },
                    {
                        label: "操作",
                        align: "center",
                        //单元格自定义渲染操作
                        opts: [
                            {
                                //按钮名称
                                title: "修改",
                                //回调事件，入参：（1：行数据，2：行角标）
                                click: this.editRow
                            },
                            {
                                title: "删除",
                                click: this.deleteRow
                            }
                        ]
                    }
                ]
            };
        },
        methods: {
            //当showCheck为true时，勾选行时的回调事件，入参：勾选后的值
            onCheck(checks) {
                console.log(checks);
            },
            //新增方法回调
            addFunc() {
                this.$open({
                    title: "新增表单系统字段",
                    width: "10rem",
                    confirmText:"保存",
                    closeText:"取消",
                    component: formComponent,
                    props: {
                        flowType : this.ajaxParams.params.flowType
                    },
                    confirm: () => {
                        this.$refs.table.reload();
                    }
                });
            },
            //修改方法回调
            editRow(row, index) {
                this.$open({
                    title: "修改表单系统字段",
                    width: "10rem",
                    confirmText:"保存",
                    closeText:"取消",
                    component: formComponent,
                    props: {
                        id: row.id
                    },
                    confirm: () => {
                        this.$refs.table.reload();
                    }
                });
            },
            //删除方法回调
            deleteRow(row, index) {
                this.$confirm("是否删除?", "提示", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(() => {
                    Ajax.delete("/common/form/syscolumn/delete", {
                        id: row.id
                    }).then(res => {
                        this.$message.success("删除成功");
                        this.$refs.table.reload();
                    });
                });
            },
            setFlowType(item){
                this.ajaxParams.params.flowType = item.key;
            }
        }
    };
</script>

<style lang='scss' scoped>
    .el-card.is-always-shadow{
        background: #F2F6FC;
        color: #409EFF;
        border-color: #409EFF;
    }
</style>