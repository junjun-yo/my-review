export default {
    data() {
        return {
            rules: {
                deptName: [
                    { required: true, message: "请选择兼职部门", trigger: "blur" }
                ],
                sysUser:{
                    sortNo: [
                        { required: true, message: "请输入排序码", trigger: "blur" },
                    ],
                }
            }
        }
    }
}