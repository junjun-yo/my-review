<template>
  <oa-table
    ref="sysFormTable"
    :ajax="ajaxParams"
    :columns="columns"
    showToolbar
    showPage
    :more="false"
    :sort="['flowType','name','tableName','createDate']"
    :add="addFunc"
  ></oa-table>
</template>

<script>
import formDesign from "@/components/FormDesign/design";
import render from "@/components/FormDesign/render/render";
import store from "@/store";

export default {
  data() {
    return {
      store,
      ajaxParams: {
        url: "/common/form/page",
        method: "post",
        params: {
            createUnit: store.state.account.sysUser.unitId
        }
      },
      columns: [
        {
          label: "表单名称",
          prop: "name",
          width: "",
          align: "center"
        },
        {
            label: "表名称",
            prop: "tableName",
            width: "",
            align: "center"
        },
        {
          label: "流程类型",
          prop: "flowType",
          align: "center",
          fmt: row => {
              return this.$options.filters["dict"](row.flowType,"flowType");
          }
        },
        {
          label: "创建时间",
          prop: "createDate",
          align: "center",
          fmt: row => {
            return this.$options.filters["date"](row.createDate, "yyyy-MM-dd");
          }
        },
        // {
        //   label: "创建人",
        //   prop: "createUser",
        //   align: "center"
        // },
        {
          label: "操作",
          align: "center",
          opts: [
            {
              title: "预览",
              click: this.previewRow
            },
            {
              title: "修改",
              click: this.editRow
            },
            {
              title: "删除",
              click: this.deleteRow
            }
          ]
        }
      ]
    };
  },
  methods: {
    addFunc() {
      this.$open({
        title: "创建表单",
        fullScreen: true,
        showConfirmBtn: false,
        showCloseBtn: false,
        showClose: false,
        component: formDesign,
        confirm: () => {
          this.$refs.sysFormTable.reload();
        }
      });
    },
    previewRow(row) {
      let form = JSON.parse(row.content);
      this.$open({
        title: "预览表单",
        component: render,
        width: "10rem",
        height: "7rem",
        confirmText: "测试提交(F12查看数据集)",
        props: {
          data: form,
          value: {}
        },
        confirm: params => {
          console.log(params);
        }
      });
    },
    editRow(row) {
      this.$open({
        title: "创建表单",
        fullScreen: true,
        showConfirmBtn: false,
        showCloseBtn: false,
        component: formDesign,
        props: {
          id: row.id
        },
        confirm: () => {
          this.$refs.sysFormTable.reload();
        }
      });
    },
    deleteRow(row) {
      this.$confirm("是否确认删除?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          Ajax.delete("/common/form/delete", {
            id: row.id
          }).then(res => {
            this.$message.success("删除成功");
            this.$refs.sysFormTable.reload();
          });
        })
        .catch(() => {});
    }
  }
};
</script>

<style lang='scss' scoped>
</style>