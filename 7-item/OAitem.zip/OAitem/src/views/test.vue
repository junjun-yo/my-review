<template>
  <div style="width:500px">
    <oa-number v-model="data" :decimal="0" />
    <hr />
    {{data}}
  </div>
</template>

<script>
export default {
  data() {
    return {
      data: null
    };
  }
};
</script>

<style lang='scss' scoped>
</style>