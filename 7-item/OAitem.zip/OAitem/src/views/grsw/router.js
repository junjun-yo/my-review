const router = [
  {
    path: "grsw/sys_user_group",
    name: "grsw_user_group",
    component: resolve => require(["views/grsw/sys_user_group/index"], resolve),
    meta: { title: "常用人员组", icon: "icon-monitor" }
  },
  {
    path: "addressCard",
    name: "addressBook",
    component: resolve => require(["views/grsw/addressBook/index"], resolve),
    meta: { title: "通讯录", icon: "icon-note" }
  }
];

export default router;
