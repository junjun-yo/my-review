import Vue from "vue";
import Element from "element-ui";
import "../style/element-variables.scss";

Vue.use(Element, { size: "small" });
