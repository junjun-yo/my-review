const rules = {};

export default rules;
