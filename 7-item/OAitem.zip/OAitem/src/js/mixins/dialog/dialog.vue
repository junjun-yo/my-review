<template>
  <div v-if="show">
    <el-dialog
      :title="title"
      :visible.sync="show"
      :before-close="beforeClose"
      :closeOnPressEscape="closeOnPressEscape"
      :show-close="showClose"
      :fullscreen="fullscreen"
      :close-on-click-modal="false"
      :width="width"
      custom-class="dialog-window"
      :top="top"
      :class="{'nofooter':showCloseBtn === false && showConfirmBtn === false}"
    >
      <child
        :ref="key"
        v-bind="props"
        @confirm="childConfirm"
        @close="childClose"
        :style="childStyle"
        :class="className"
      />
      <span
        slot="footer"
        class="dialog-footer"
        v-if="showCloseBtn === true || showConfirmBtn === true"
      >
        <el-button @click="close" v-if="showCloseBtn">{{closeText}}</el-button>
        <el-button
          type="primary"
          @click="confirm"
          :loading="confirmLoading"
          v-if="showConfirmBtn"
        >{{confirmText}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      key: "dialog" + new Date().getTime()
    };
  },
  computed: {
    childStyle() {
      let overflowY = "";
      if (this.height != "auto") {
        overflowY = "auto";
      } else {
        overflowY = "";
      }
      if (this.fullscreen === true) {
        this.$set(this, "height", "100%");
      }
      return {
        height: this.height,
        "overflow-y": overflowY
      };
    }
  }
};
</script>

<style lang='scss'>
.dialog-window {
  border-radius: 7px;
  .el-dialog__body {
    padding: 5px 20px 5px 20px;
  }
  &.is-fullscreen {
    .el-dialog__body {
      height: calc(100% - 130px);
    }
  }
}
.nofooter .dialog-window {
  &.is-fullscreen {
    .el-dialog__body {
      height: calc(100% - 60px);
    }
  }
}
</style>