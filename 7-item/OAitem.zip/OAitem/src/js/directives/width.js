export default {
    bind: function (el, binding) {
        el.style.width = binding.value + 'px'
    }
}