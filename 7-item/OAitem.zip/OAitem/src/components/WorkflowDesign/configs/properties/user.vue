<template>
    <el-form :model="data" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-tabs v-model="activeName">
            <el-tab-pane label="基础属性" name="base" style="padding: 10px;height: 460px;overflow-y: auto;">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="节点标识" prop="id">
                            <el-input v-model="data.id" :disabled="true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="节点名称" prop="name">
                            <el-input v-model="data.name"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-form-item label="节点备注">
                            <el-input
                                    type="textarea"
                                    v-model="data.property.documentation"
                                    placeholder="流程备注说明"
                                    :autosize="{ minRows: 2, maxRows: 5}"
                            />
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="办理期限" prop="property.assigneeDay">
                            <el-input-number v-model="data.property.assigneeDay" :min="0" :max="99" :precision="0"/>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="自由选择">
                            <el-switch v-model="data.property.isFreedom" :active-value="1"
                                       :inactive-value="0"></el-switch>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="可选人数" prop="property.assigneeMax">
                            <el-input-number v-model="data.property.assigneeMax" :min="1" :max="20" :precision="0"/>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-tab-pane>
            <el-tab-pane label="操作权限" name="puts" style="padding: 10px;height: 460px;overflow-y: auto;">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="意见类型" prop="property.approvalType">
                            <oa-select v-model="data.property.approvalType" code="approvalType"></oa-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="意见权限">
                            <oa-radio v-model="data.property.approvalLimits" :options="optApprovalLimits"/>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24">
                        <el-form-item label="意见格式">
                            <el-input
                                    type="textarea"
                                    v-model="data.property.approvalFmt"
                                    placeholder="意见格式模板"
                                    autosize
                            />
                        </el-form-item>
                    </el-col>
                    <el-col :span="10">
                        <el-row>
                            <el-col :span="12">
                                <el-form-item label="编辑正文">
                                    <el-switch v-model="data.property.isEditFile" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="设置红头">
                                    <el-switch v-model="data.property.isRedHead" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="保留痕迹">
                                    <el-switch v-model="data.property.isTrace" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="生成正文">
                                    <el-switch v-model="data.property.isBuildFile" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="版式文件">
                                    <el-switch v-model="data.property.isBuildPdf" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="电子印章">
                                    <el-switch v-model="data.property.isSignature" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="上传附件">
                                    <el-switch v-model="data.property.isUpload" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="下载附件">
                                    <el-switch v-model="data.property.isDownload" :active-value="1"
                                               :inactive-value="0"></el-switch>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-col>
                    <el-col :span="14">
                        <oa-select :options="optButtons" v-model="checkedButton"></oa-select>
                        <el-button type="primary" plain icon="el-icon-plus" @click="addButton">添加按钮</el-button>
                        <el-table :data="data.buttons" height="220" border>
                            <el-table-column prop="btnKey" label="按钮标识" align="center">
                            </el-table-column>
                            <el-table-column label="按钮名称" align="center">
                                <template slot-scope="{row}">
                                    <el-input v-model="row.btnName"></el-input>
                                </template>
                            </el-table-column>
                            <el-table-column label="操作" width="100" align="center">
                                <template slot-scope="scope">
                                    <el-link type="primary" @click="upBtn(scope.row,scope.$index)" icon="el-icon-top"
                                             :underline="false"/>
                                    <el-divider direction="vertical"></el-divider>
                                    <el-link type="primary" @click="downBtn(scope.row,scope.$index)"
                                             icon="el-icon-bottom" :underline="false"/>
                                    <el-divider direction="vertical"></el-divider>
                                    <el-link type="primary" @click="removeBtn(scope.row)" icon="el-icon-close"
                                             :underline="false"/>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                </el-row>
            </el-tab-pane>
            <el-tab-pane label="人员配置" name="assignees" style="padding: 10px;height: 460px;overflow-y: auto;">
                <el-row>
                    <el-col :span="12">
                        <el-button-group>
                            <el-button type="primary" plain icon="el-icon-user" @click="addUser">添加人员</el-button>
                            <el-button type="primary" plain icon="el-icon-share" @click="addDept">添加部门</el-button>
                            <el-button type="primary" plain icon="el-icon-user-solid" @click="addRole">添加角色</el-button>
                        </el-button-group>
                    </el-col>
                    <el-col :span="12">
                        <label>过滤条件&nbsp;&nbsp;</label>
                        <oa-select v-model="data.property.assigneeFilter" :options="optAssigneeFilter"/>
                    </el-col>
                    <el-col :span="12">
                        <el-table :data="users" height="340" border>
                            <el-table-column prop="assigneeName" label="人员姓名" align="center">
                            </el-table-column>
                            <el-table-column label="操作" width="100" align="center">
                                <template slot-scope="{row}">
                                    <el-link type="primary" @click="removeUser(row)" icon="el-icon-delete"
                                             :underline="false">删除
                                    </el-link>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                    <el-col :span="12">
                        <el-table :data="depts" height="170" border>
                            <el-table-column prop="assigneeName" label="部门名称" align="center">
                            </el-table-column>
                            <el-table-column label="操作" width="100" align="center">
                                <template slot-scope="{row}">
                                    <el-link type="primary" @click="removeDept(row)" icon="el-icon-delete"
                                             :underline="false">删除
                                    </el-link>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                    <el-col :span="12">
                        <el-table :data="roles" height="170" border>
                            <el-table-column prop="assigneeName" label="角色名称" align="center">
                            </el-table-column>
                            <el-table-column label="操作" width="100" align="center">
                                <template slot-scope="{row}">
                                    <el-link type="primary" @click="removeRole(row)" icon="el-icon-delete"
                                             :underline="false">删除
                                    </el-link>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-col>
                    <!--<el-col :span="24" style="margin-top: 10px;">-->
                        <!--<el-form-item label="过滤条件">-->
                            <!--<oa-radio-->
                                    <!--v-model="data.property.assigneeFilter"-->
                                    <!--placeholder="请选择人员过滤方式"-->
                                    <!--:options="optAssigneeFilter"-->
                            <!--/>-->
                        <!--</el-form-item>-->
                    <!--</el-col>-->
                </el-row>
            </el-tab-pane>
            <el-tab-pane label="参数配置" name="params" style="padding: 10px;height: 460px;overflow-y: auto;">
                <el-row>
                    <el-col :span="6">
                        <el-card class="box-card">
                            <div slot="header" class="clearfix">
                                <span>可编辑参数</span>
                            </div>
                            <div class="paramPanel">
                                <el-checkbox-group v-model="checkedEditParam">
                                    <el-checkbox v-if="param.paramType == 'EDIT'"
                                                 v-for="param in data.params" :key="param.paramName"
                                                 :label="param.paramName"></el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-card>
                    </el-col>
                    <el-col :span="3" class="moveCol">
                        <el-button class="moveBtn" @click="toEditParam"><==</el-button>
                        <br/>
                        <el-button class="moveBtn" @click="toReadParam(checkedEditParam)">==></el-button>
                    </el-col>
                    <el-col :span="6">
                        <el-card class="box-card">
                            <div slot="header" class="clearfix">
                                <span>只读参数</span>
                            </div>
                            <div class="paramPanel">
                                <el-checkbox-group v-model="checkedReadParam">
                                    <el-checkbox v-if="param.paramType == 'READ'"
                                                 v-for="param in data.params" :key="param.paramName"
                                                 :label="param.paramName"></el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-card>
                    </el-col>
                    <el-col :span="3" class="moveCol">
                        <el-button class="moveBtn" @click="toReadParam(checkedHideParam)"><==</el-button>
                        <br/>
                        <el-button class="moveBtn" @click="toHideParam">==></el-button>
                    </el-col>
                    <el-col :span="6">
                        <el-card class="box-card">
                            <div slot="header" class="clearfix">
                                <span>隐藏参数</span>
                            </div>
                            <div class="paramPanel">
                                <el-checkbox-group v-model="checkedHideParam">
                                    <el-checkbox v-if="param.paramType == 'HIDE'"
                                                 v-for="param in data.params" :key="param.paramName"
                                                 :label="param.paramName"></el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-tab-pane>
        </el-tabs>
    </el-form>
</template>

<script>

    export default {
        props: {
            selectNode: Object,
            structs:Array 
        },
        mounted(){
            //初始化表单参数设置信息
            if(!this.data.params || this.data.params.length == 0 || !this.validateParam()){
                this.data.params = [];
                if(this.structs.length > 0){
                    for(let i in this.structs){
                        this.data.params.push({
                            paramType: "READ",
                            paramName: this.structs[i].name,
                            putType: "FORM"
                        });
                    }
                }
            }
            this.checkedReadParam = [];
            this.checkedHideParam = [];
            this.checkedEditParam = [];
            if(this.data.assignees && this.data.assignees.length > 0){
                for(let i in this.data.assignees){
                    switch (this.data.assignees[i].assigneeType) {
                        case "USER":
                            this.users.push({...this.data.assignees[i]});
                            break;
                        case "DEPT":
                            this.depts.push({...this.data.assignees[i]});
                            break;
                        case "ROLE":
                            this.roles.push({...this.data.assignees[i]});
                            break;
                    }
                }
            }
        },
        data() {
            return {
                data: {
                    ...{
                        stepKey: "",
                        stepName: "",
                        stepType: "USERTASK",
                        property: {
                            assigneeDay: 3,
                            isFreedom: 0,
                            assigneeMax: 1,
                            documentation: "",
                            assigneeFilter: "NONE",
                            isEditFile: 1,
                            isRedHead: 0,
                            isTrace: 0,
                            isBuildFile: 0,
                            isBuildPdf: 0,
                            isSignature: 0,
                            isUpload: 1,
                            isDownload: 1,
                            approvalType: "01",
                            approvalLimits: "NOT",
                            approvalFmt: ""
                        },
                        assignees: [],
                        params: [],
                        buttons: []
                    },
                    ...this.selectNode
                },
                users: [],
                roles: [],
                depts: [],
                activeName: "base",
                checkedButton: "",
                checkedReadParam: [],
                checkedHideParam: [],
                checkedEditParam: [],
                form: {},
                rules: {
                    id: [{required: true, message: "步骤标识不能为空", trigger: "blur"}],
                    name: [
                        {required: true, message: "步骤名称不能为空", trigger: "blur"}
                    ],
                    "property.assigneeDay": [
                        {required: true, message: "办理期限不能为空", trigger: "blur"}
                    ],
                    "property.assigneeMax": [
                        {required: true, message: "可选人数不能为空", trigger: "blur"}
                    ],
                    "property.approvalType": [
                        {required: true, message: "请选择意见类型", trigger: "blur"}
                    ]
                },
                optAssigneeFilter: [
                    {label: "不过滤", value: "NONE"},
                    {label: "同单位", value: "UNIT"},
                    {label: "同部门", value: "DEPT"},
                    {label: "同科室", value: "OFFICE"},
                    {label: "同行政区域", value: "DOMAIN"},
                    {label: "起草人", value: "DRAFTER"},
                    {label: "上一执行人", value: "PERVER"},
                    {label: "上一执行人同部门", value: "PERVER_DEPT"},
                    {label: "上一执行人同科室", value: "PERVER_OFFICE"},
                    {label: "上一执行人部门领导", value: "PERVER_MANAGE"},
                    {label: "上一执行人部门文书", value: "PERVER_DOC"}
                ],
                optApprovalLimits: [
                    {label: "不填", value: "NOT"},
                    {label: "可填", value: "YES"},
                    {label: "必填", value: "REQUIRED"}
                ],
                optButtons: [
                    {label: "发送", value: "发送"},
                    {label: "发相关人员", value: "发相关人员"},
                    {label: "发相关单位", value: "发相关单位"},
                    {label: "转档案系统", value: "转档案系统"},
                    {label: "发内网门户", value: "发内网门户"}
                ]
            };
        },
        computed: {},
        methods: {
            //整理数据
            buildData(){
                this.data.stepKey = this.data.id;
                this.data.stepName = this.data.name;
                for(let i in this.data.buttons){
                    this.data.buttons[i].sort = parseInt(i)+1;
                }
                this.data.assignees = this.users.concat(this.depts.concat(this.roles));
            },
            //面板关闭处理
            confirm(done, fail) {
                this.$refs.ruleForm.validate(valid => {
                    if (valid) {
                        this.buildData();
                        done(this.data);
                    } else {
                        fail();
                    }
                });
            },
            //添加用户对象
            addUser() {
                this.$openUserSelect({
                    allData:true,
                    confirm: data => {
                        //多个为id的数组，一个为id的字符串
                        if(data instanceof Array){
                            for(let i in data){
                                this.users.push({assigneeId: data[i].key, assigneeName: data[i].label, assigneeType:"USER"});
                            }
                        }else{
                            this.users.push({assigneeId: data.key, assigneeName: data.label, assigneeType:"USER"});
                        }
                    }
                });
            },
            //添加部门对象
            addDept() {
                this.$openDeptSelect({
                    confirm: data => {
                        if(data && data.length>0){
                            for(let i in data){
                                this.depts.push({assigneeId: data[i].id, assigneeName: data[i].name, assigneeType: "DEPT"});
                            }
                        }
                    }
                });
            },
            //添加角色对象
            addRole() {
                let defaults = this.roles.map(item => item.assigneeId).join(",");
                this.$openRoleSelect({
                    defaultCheck: defaults,
                    confirm: data => {
                        this.roles = [];
                        if(data && data.length>0){
                            for(let i in data){
                                let item = {assigneeId: data[i].key, assigneeName: data[i].label, assigneeType: "ROLE"};
                                this.roles.push(item);
                            }
                        }
                    }
                });
            },
            //添加按钮对象
            addButton() {
                if (this.checkedButton && this.checkedButton != "") {
                    let btn = {btnKey: this.checkedButton, btnName: this.checkedButton};
                    this.data.buttons.push(btn);
                }
            },
            //删除用户
            removeUser(row) {
                this.users.splice(this.users.indexOf(row), 1);
            },
            //删除部门
            removeDept(row) {
                this.depts.splice(this.depts.indexOf(row), 1);
            },
            //删除角色
            removeRole(row) {
                this.roles.splice(this.roles.indexOf(row), 1);
            },
            //删除按钮
            removeBtn(row) {
                this.data.buttons.splice(this.data.buttons.indexOf(row), 1);
            },
            //上移按钮对象
            upBtn(row, index) {
                if (index > 0) {
                    let tmpItem = this.data.buttons[index - 1];
                    this.$set(this.data.buttons, index - 1, row);
                    this.$set(this.data.buttons, index, tmpItem);
                }
            },
            //下移按钮对象
            downBtn(row, index) {
                if (index < this.data.buttons.length - 1) {
                    let tmpItem = this.data.buttons[index + 1];
                    this.$set(this.data.buttons, index + 1, row);
                    this.$set(this.data.buttons, index, tmpItem);
                }
            },
            //移动只读参数到隐藏参数列
            toHideParam(){
                this.moveParam(this.checkedReadParam,"HIDE");
            },
            //移动只读参数到编辑参数列
            toEditParam(){
                this.moveParam(this.checkedReadParam,"EDIT");
            },
            //移动指定参数到只读参数列
            toReadParam(checked){
                this.moveParam(checked,"READ");
            },
            //设置指定参数在参数集合中的的状态
            moveParam(checked,paramType){
                if(checked && checked.length>0){
                    for(let i in checked) {
                        for(let j in this.data.params){
                            if(this.data.params[j].paramName == checked[i]){
                                this.$set(this.data.params[j],"paramType",paramType);
                                break;
                            }
                        }
                    }
                    this.checkedReadParam = [];
                    this.checkedHideParam = [];
                    this.checkedEditParam = [];
                }
            },
            //验证当前params参数和表字段是否匹配
            validateParam(){
                if(this.structs && this.structs.length !== this.data.params.length){
                    return false;
                }else{
                    for(let i in this.structs){
                        let ok = false;
                        for(let j in this.data.params){
                            if(this.structs.name == this.data.params.paramName){
                                ok = true;
                                break;
                            }
                        }
                        if(!ok){
                            return false;
                        }
                    }
                    return true;
                }
            }
        }
    };
</script>

<style lang='scss' scoped>
    .moveCol {
        text-align: center;
        vertical-align: middle;
        padding-top: 160px;
    }

    .moveBtn {
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .paramPanel {
        height: 300px;
        width: 100%;
        overflow-y: auto;
    }
    .paramPanel .el-checkbox {
        font-size: 18px;
        line-height: 30px;
        width:100%;
        margin: 0px;
        padding: 0px;
    }
</style>