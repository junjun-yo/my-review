<template>
  <div class="user-select-dialog">
    <div class="first-tab">
      <ul class="select-tab-menu">
        <li v-for="(menu,i) in menus">
          <div
            class="menu-span"
            :class="menu.id === curMenu?'active':''"
            @click="menuClick(menu)"
          >{{menu.title}}</div>
          <div class="menu-split" v-if="i != menus.length-1"></div>
        </li>
      </ul>
      <el-autocomplete
        style="float:right;margin-top:4px;"
        popper-class="search-user"
        v-model="searchData"
        :fetch-suggestions="searchUser"
        placeholder="请输入人员名称"
        @select="selectUser"
      >
        <i class="el-icon-search el-input__icon" slot="suffix"></i>
        <template slot-scope="{ item }">
          <div class="name">{{ item.label }}</div>
          <span class="desc">{{ item.data.deptName }}</span>
        </template>
      </el-autocomplete>
    </div>
    <div class="second-tab" v-if="curMenu == 0">
      <div class="user-type-list">
        <div class="usertype" v-for="(userType,i) in userTypes">
          <div
            class="user-span"
            :class="userType.id === curUserType?'active':''"
            @click="userTypeClick(userType)"
          >{{userType.title}}</div>
          <div class="menu-split" v-if="i != userTypes.length-1"></div>
        </div>
      </div>
    </div>
    <div class="content">
      <el-row :gutter="20" class="full" style="height:4rem">
        <el-col :span="7" v-loading="treeloaing">
          <ztree @click="nodeClick" noDefaultSelect title="节点" ref="deptTree" :treeData="treeData" />
        </el-col>
        <el-col :span="17">
          <transfer
            :loading="transferLoading"
            v-model="chooses"
            :data="dataSources"
            :allowCheckCount="allowCheckCount"
            :titles="['人员列表','已选择']"
            :props="transferProp"
          />
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import userSelectDialogMixin from "./user-select-dialog-mixin";
import store from "@/store";
import transfer from "@/components/Transfer";
export default {
  mixins: [userSelectDialogMixin],
  props: {
    allowCheckCount: Number,
    defaultCheck: [String, Array]
  },
  components: {
    transfer
  },
  watch: {
    defaultCheck() {
      this.transformDefaultCheck();
    }
  },
  data() {
    return {
      curNode: {},
      dataSources: [],
      chooses: [],
      treeData: [],
      treeloaing: false,
      transferLoading: false,
      //搜索相关
      searchLoading: false,
      searchData: "",
      searchList: [],
      searchName: "",
      transferProp: {
        key: "userId",
        label: "userName"
      }
    };
  },
  methods: {
    selectUser(val) {
      this.searchData = "";
      const target = this.chooses.find(item => {
        return item.key == val.key;
      });
      if (!target) {
        this.chooses.push(val);
      }
    },
    searchUser(userName, done) {
      if (userName !== "") {
        this.searchLoading = true;
        let param = {
          showType: "4",
          userName: userName
        };
        //本单位查询
        if (this.curMenu == 0) {
          param = Object.assign(param, {
            queryId: this.curNode.deptId
          });
        }
        Ajax.post("/system/addressBook/searchUserList", param).then(
          ({ data }) => {
            this.searchLoading = false;
            if (data && data.length > 0) {
              const newData = data.map(item => {
                return {
                  key: item.userId,
                  label: item.userName,
                  data: item
                };
              });
              done(newData);
            } else {
              this.searchData = "";
              done([]);
            }
          },
          err => {
            this.searchData = "";
            this.$message.error("查询失败");
          }
        );
      } else {
        this.searchData = "";
        done([]);
      }
    },
    async transformDefaultCheck() {
      if (this.defaultCheck && this.defaultCheck.length > 0) {
        let id = "";
        if (this.defaultCheck.constructor == Array) {
          id = this.defaultCheck.join(",");
        } else {
          id = this.defaultCheck;
        }
        let param = { id };
        const { data } = await Ajax.post(
          "/common/cacheData/searchNameForUser",
          param
        );
        if (data && data.length > 0) {
          const chooses = [];
          const names = data.split(",");
          names.forEach((name, i) => {
            chooses.push({
              key: id.split(",")[i],
              label: name
            });
          });
          this.chooses = chooses;
        } else {
          // done([]);
        }
      }
    },
    confirm(done, fail) {
      const data = this.chooses.map(item => {
        return {
          key: item[this.transferProp.key] || item.key,
          label: item[this.transferProp.label] || item.label
        };
      });
      done(data);
    },
    nodeClick(data) {
      const item = data.item;
      this.curNode = item;
      this.loadUserList();
    },
    loadUserList() {
      let params = {};
      //所有单位部门树
      if (this.curMenu == 1 && this.curUserType == 0) {
        params = {
          showType: "1",
          queryId: this.curNode.deptId
        };
      }
      //本单位部门树
      if (this.curMenu == 0 && this.curUserType == 0) {
        params = {
          showType: "1",
          queryId: this.curNode.deptId
        };
      }
      //本单位角色树
      if (this.curMenu == 0 && this.curUserType == 1) {
        params = {
          showType: "2",
          queryId: this.curNode.id
        };
      }

      //本单位分组树
      if (this.curMenu == 0 && this.curUserType == 2) {
        params = {
          showType: "3",
          queryId: this.curNode.id
        };
      }
      this.transferLoading = true;
      //人员列表查询
      Ajax.post("/system/addressBook/searchUserList", params).then(
        res => {
          this.dataSources = res.data;
          this.transferLoading = false;
        },
        err => {
          this.$message.error("人员列表加载异常");
          this.transferLoading = false;
        }
      );
    },
    resetAndLoadTreeInfo() {
      let params = {};
      //所有单位部门树
      if (this.curMenu == 1 && this.curUserType == 0) {
        params = {
          showType: "1"
        };
      }
      //本单位部门树
      if (this.curMenu == 0 && this.curUserType == 0) {
        params = {
          showType: "1",
          queryId: store.state.account.sysUser.deptId
        };
      }
      //本单位角色树
      if (this.curMenu == 0 && this.curUserType == 1) {
        params = {
          showType: "2"
        };
      }

      //本单位分组树
      if (this.curMenu == 0 && this.curUserType == 2) {
        params = {
          showType: "3",
          queryId: this.curNode.id
        };
      }
      this.treeloaing = true;
      Ajax.post("/system/addressBook/selectUserTreeList", params).then(
        res => {
          this.treeData = res.data;
          this.treeloaing = false;
        },
        err => {
          this.$message.error("树加载异常");
          this.treeloaing = false;
        }
      );
      this.dataSources = [];
    }
  },
  created() {
    this.transformDefaultCheck();
    this.resetAndLoadTreeInfo();
  }
};
</script>

<style lang='scss' scoped>
.search-user {
  .el-autocomplete-suggestion__wrap {
    padding: 10px 0 0 0;
  }
  li {
    line-height: normal;
    padding: 7px;

    .name {
      display: inline-block;
      vertical-align: middle;
      width: 50%;
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .desc {
      display: inline-block;
      vertical-align: middle;
      width: 50%;
      font-size: 12px;
      color: #b4b4b4;
    }

    .highlighted .desc {
      color: #ddd;
    }
  }
}

.user-select-dialog {
  .content {
    margin-top: 10px;
  }
  .first-tab {
    border-top: 1px solid #e4e4e4;
    border-bottom: 1px solid #e4e4e4;
    height: 38px;
    padding: 0 10px;
    width: 100%;
    margin-left: -4px;
    .select-tab-menu {
      padding: 0;
      margin-top: 7px;
      background: #fff;
      float: left;
      height: 24px;
      line-height: 24px;
      overflow-y: hidden;
      white-space: nowrap;
      clear: both;
      & li {
        float: left;
        height: 24px;
        line-height: 24px;
        text-align: center;
        cursor: pointer;
        list-style-type: none;
        width: auto;
        & .menu-span {
          padding-left: 18px;
          padding-right: 18px;
          font-weight: 400;
          float: left;
          margin-right: 10px;
          margin-left: 10px;
          height: 24px;
          line-height: 24px;
          border-radius: 4px;
          &.active {
            color: #fff;
            background-color: #039adf;
          }
        }
      }
    }
  }
  .menu-split {
    width: 1px;
    float: left;
    height: 16px;
    border-right-color: #ccc;
    border-right-width: 1px;
    border-right-style: solid;
    margin-top: 4px;
  }
  .second-tab {
    height: 40px;
    padding: 0 10px;
    width: 100%;
    margin-left: -4px;
    border-bottom: 1px solid #e4e4e4;
    .user-type-list {
      padding: 0;
      margin: 0;
      background: #fff;
      float: left;
      height: 38px;
      line-height: 38px;
      overflow-y: hidden;
      white-space: nowrap;
      clear: both;
      width: 100%;
      margin-left: -10px;
      & .usertype {
        float: left;
        margin-left: 1px;
        margin-right: 1px;
        height: 24px;
        margin-top: 6px;
        & .user-span {
          float: left;
          height: 24px;
          line-height: 24px;
          text-align: center;
          cursor: pointer;
          padding-left: 16px;
          padding-right: 16px;
          font-weight: 400;
          margin-left: 1px;
          margin-right: 1px;
          &.active {
            color: #039adf;
          }
        }
      }
    }
  }
}
</style>