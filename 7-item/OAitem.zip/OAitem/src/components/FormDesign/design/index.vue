<template>
  <el-container class="design-console" v-loading="loading">
    <el-header class="design-info">
      <el-form :inline="true" :model="widgetForm" :rules="rules" ref="configForm">
        <el-form-item label="表单名称" prop="config.name">
          <el-input v-model="widgetForm.config.name" placeholder="请输入表单名称"></el-input>
        </el-form-item>
        <el-form-item label="流程类型" prop="config.flowType">
          <oa-select v-model="widgetForm.config.flowType" placeholder="请选择所属分类" code="flowType"/>
        </el-form-item>
        <el-form-item label="表单类型" prop="config.types">
          <oa-select style="width: 400px;" v-model="widgetForm.config.types"
                     multiple placeholder="请选择表单类型" :options="optFormType"
                     optKey="id" optValue="id" optLabel="codePrefix"/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="save" :loading="saveLoading">保存</el-button>
          <el-button type="primary" @click="close">关闭</el-button>
        </el-form-item>
      </el-form>
    </el-header>
    <el-divider></el-divider>
    <el-container class="content">
      <el-aside class="components">
        <el-container>
          <el-header class="components-title">
            <div class="design-title">表单控件</div>
          </el-header>
          <el-main class="components-list">
            <draggable
              tag="ul"
              :list="components"
              v-bind="{group:{ name:'people', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}"
              :move="()=>true"
            >
              <li
                class="form-edit-widget-label no-put"
                v-for="(item, index) in components"
                :key="index"
              >
                <a>
                  <i :class="item.icon"></i>
                  <span>{{item.name}}</span>
                </a>
              </li>
            </draggable>
          </el-main>
          <el-footer class="field-list">
            <div class="design-title">表单字段</div>
            <ul class="list">
              <li v-for="field in fields">{{field}}</li>
            </ul>
          </el-footer>
        </el-container>
      </el-aside>
      <el-container class="design">
        <el-header class="design-tool">
          <el-button type="danger" @click="clear">清空</el-button>
          <el-button type="success" @click="importJson">导入JSON</el-button>
          <el-button type="primary" @click="json">生成JSON</el-button>
          <!-- <el-button type="primary" @click="code">生成代码</el-button> -->
          <el-button type="primary" @click="preview">预览表单</el-button>
        </el-header>
        <el-divider></el-divider>
        <el-main class="disign-area">
          <widget-form :data="widgetForm" :select.sync="widgetFormSelect" />
        </el-main>
      </el-container>
      <el-aside class="config">
        <div class="design-title">控件配置</div>
        <form-config :data="widgetFormSelect" />
      </el-aside>
    </el-container>
  </el-container>
</template>

<script>
//vuex
import store from "@/store";

//表单设计器相关组件
import formConfig from "./form_config";
import components from "../config";
import draggable from "vuedraggable";
import widgetForm from "./widget_form";

//弹窗
import preview from "../dialog/preview";
import json from "../dialog/json";
import importJson from "../dialog/import_json";
import code from "../dialog/code";

//辅助
import generate from "../render/generate_vue";
import { buildParamKeys } from "../render/rebuild_form";
var beautify_html = require("js-beautify").html;

export default {
  props: {
    id: String
  },
  components: {
    formConfig,
    draggable,
    widgetForm
  },
  data() {
    return {
      components,
      widgetFormSelect: {},
      widgetForm: {
        list: [],
        config: {
          name: "",
          flowType: "",
          types: []
        }
      },
      loading: false,
      rules: {
        "config.name": [
          { required: true, message: "请输入表单名称", trigger: "change" }
        ],
        "config.flowType": [
          { required: true, message: "请选择流程类型", trigger: "change" }
        ],
        "config.types": [
          { required: true, message: "请选择表单类型", trigger: "change" }
        ]
      },
      saveLoading: false,
      optFormType: []
    };
  },
  watch: {
    flowType(newValue,oldValue) {
      this.loadFormType(newValue,(oldValue && oldValue!=''));
    }
  },
  computed: {
    fields() {
      let keys = buildParamKeys(this.widgetForm);
      return keys;
    },
    createInfo() {
      const sysUser = store.state.account.sysUser;
      return {
        createUser: sysUser.userId,
        createDept: sysUser.deptId,
        createUnit: sysUser.unitId
      };
    },
    user() {
      return store.state.account.sysUser;
    },
    flowType(){
      return this.widgetForm.config.flowType;
    }
  },
  methods: {
    clear() {
      this.widgetForm = {
        list: [],
        config: {
          labelWidth: 100,
          labelPosition: "right",
          size: "small",
          customClass: ""
        }
      };
      this.widgetFormSelect = {};
    },
    preview() {
      this.$open({
        title: "预览表单",
        component: preview,
        width: "13rem",
        height: "6rem",
        props: {
          data: this.widgetForm,
          value: {}
        }
      });
    },
    json() {
      this.$open({
        title: "JSON数据",
        component: json,
        height: "5rem",
        showConfirmBtn: false,
        props: {
          data: this.widgetForm
        }
      });
    },
    importJson() {
      this.$open({
        title: "导入JSON数据",
        component: importJson,
        height: "5rem",
        props: {
          data: this.widgetForm
        },
        confirm: data => {
          this.widgetForm = data;

          if (data.list.length > 0) {
            this.widgetFormSelect = data.list[0];
          }
        }
      });
    },
    loadFormInfo() {
      this.loading = true;
      Ajax.post("/common/form/get", {
        id: this.id
      }).then(res => {
        let form = JSON.parse(res.data.content);
        this.widgetForm = form;
        if (form.list.length > 0) {
          this.widgetFormSelect = form.list[0];
        }
        this.loading = false;
      });
    },
    code() {
      this.$open({
        title: "代码",
        component: code,
        showConfirmBtn: false,
        props: {
          data: this.widgetForm
        }
      });
    },
    save() {
      this.$refs["configForm"].validate(valid => {
        if (valid) {
          let content = this.widgetForm;
          let source = beautify_html(generate(this.widgetForm), {
            indent_size: 2
          });
          let param = Object.assign(
            {},
            this.widgetForm.config,
            this.createInfo,
            {
              content: JSON.stringify(content),
              source: source
            }
          );

          if (this.id) {
            param = Object.assign(param, {
              id: this.id
            });
          }
          let types = [];
          for(let i in param.types){
              types.push({"id":param.types[i]});
          }
          param.types = types;

          this.saveLoading = true;
          Ajax.put("/common/form/save", param, "json").then(
            res => {
              this.$message.success("保存成功");
              this.saveLoading = false;
              this.$emit("confirm");
            },
            err => {
              this.saveLoading = false;
              this.$message.success("保存失败");
            }
          );
        } else {
          return false;
        }
      });
    },
    close() {
      this.$emit("close");
    },
    loadFormType(flowType,isClear){
        this.optFormType = [];
        if(isClear){
            this.widgetForm.config.types = [];
        }
        if(flowType && flowType!=''){
          Ajax.post("/common/form/type/list",{
              "unitId" : store.state.account.sysUser.unitId,
              "flowType" : flowType
          }).then(res => {
            this.optFormType = res.data;
          });
        }
    }
  },
  created() {
    if (this.id) {
      this.loadFormInfo();
    }
  }
};
</script>

<style lang='scss' scoped>
.design-console {
  height: 100%;
  .design-info {
    display: flex;
    justify-content: flex-end;
    flex-direction: row;
    align-items: top;
    .el-form-item {
      margin-bottom: 0;
    }
  }
  .el-container {
    height: 100%;
  }
  .el-divider {
    margin: 0;
  }
  .el-main {
    padding: 0;
  }
  .design-title {
    color: $--color-primary;
    font-size: 18px;
    font-weight: bold;
    &:before {
      content: "";
      height: 30px;
      border-left: 5px solid $--color-primary;
      padding-right: 10px;
    }
  }
  .content {
    .components {
      width: 250px;
      .components-title {
        height: 50px !important;
        padding: 0 10px;
        display: flex;
        align-items: center;
      }
      .components-list {
        padding: 8px 0;
        width: 100%;
        height: 100%;
        ul {
          position: relative;
          overflow: hidden;
          padding: 0 10px 10px;
          margin: 0;
        }
        li {
          font-size: 12px;
          display: block;
          width: 48%;
          line-height: 26px;
          position: relative;
          float: left;
          left: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          margin: 1%;
          color: #333;
          border: 1px solid #f4f6fc;
          margin-bottom: 15px;

          &:hover {
            color: $--color-primary;
            border: 1px dashed $--color-primary;
          }

          & > a {
            display: block;
            cursor: move;
            background: #f4f6fc;
            border: 1px solid #f4f6fc;
            padding-left: 10px;
            .icon {
              margin-right: 6px;
              margin-left: 8px;
              font-size: 14px;
              display: inline-block;
              vertical-align: middle;
            }

            span {
              display: inline-block;
              vertical-align: middle;
              margin-left: 5px;
            }
          }
        }
      }
      .field-list {
        padding: 10px;
        height: 300px !important;
        border-top: 1px solid #dcdfe6;
        & .list {
          border: 1px solid #dcdfe6;
          margin-top: 10px;
          height: calc(100% - 30px);
          overflow-y: auto;
          & li {
            padding: 10px 10px;
            margin: 0 10px;
            border-bottom: 1px solid #dcdfe6;
            &::before {
              content: "\21C5";
              padding-right: 5px;
              cursor: move;
            }
          }
        }
      }
    }
    .design {
      border-left: 1px solid #dcdfe6;
      border-right: 1px solid #dcdfe6;
      .design-tool {
        height: 50px !important;
        display: flex;
        justify-content: flex-end;
        flex-direction: row;
        align-items: center;
        .el-button {
          margin-left: 10px;
        }
      }
      .disign-area {
        background: rgb(245, 246, 247, 0.3);
        padding: 10px;
      }
    }
    .config {
      padding: 10px;
      width: 250px;
      overflow: hidden;
    }
  }
}
</style>