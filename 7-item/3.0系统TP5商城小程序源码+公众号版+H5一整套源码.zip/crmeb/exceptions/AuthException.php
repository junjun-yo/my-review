<?php


namespace crmeb\exceptions;


use Throwable;

class AuthException extends \Exception
{

}