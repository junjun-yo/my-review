<?php
/**
 * Created by CRMEB.
 * User: 136327134@qq.com
 * Date: 2019/4/9
 * Time: 14:18
 */

namespace crmeb\interfaces;

/*
 * 工厂模式服务注册接口类
 *
 * */

interface ProviderInterface
{

    public function register($config);

}

